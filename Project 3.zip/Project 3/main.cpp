#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
#include <sstream>
using namespace std;



struct noMatch  
{ 


  string nomatchtag;
  noMatch  *next;

};


 

struct alphabeticaTag  
{ 

string matchTag;
int matchcount;
string nomatchTag;
int nomatchcount;
alphabeticaTag *next;
};








template<class ItemType>

class Stack

{

    private:

    ItemType arrayStack [100];               

    int topOfStack;

    public:

    Stack()

    {

        topOfStack = -1;

    }

    Stack(const Stack<ItemType> &x)

    {

        for(int i = 0; i<=x.topOfStack; i++)
{

            arrayStack[i] = x.arrayStack[i];
}
        topOfStack = x.topOfStack;

    }

    void MakeEmpty()

    {

        topOfStack = -1;

    }

    bool IsEmpty()

    {

        if(topOfStack == -1)

            return true;

        return false;

    }

    bool IsFull()

    {

        if(length() == 5)

            return true;

        return false;

    }

    int length()

    {

        return topOfStack+1;

    }

    void Print(ofstream &outFile)

    {

        for(int i =0 ; i <length(); i++)
{

            cout<<arrayStack[i]<<" ";
outFile<<arrayStack[i]<<" ";}
        cout<<endl;

    }

    bool Push(ItemType x)

    {
    	
    
    	
    	
    	

        if(!IsFull())
{

            arrayStack[++topOfStack] = x;
            return true;
        }

    }

    bool Pop(ItemType &x)

    {
    	
    	
    	
    

        if(IsEmpty() )
{

            return false;}

        topOfStack--;

    }

    ItemType Peek(bool &status)

    {

        if(topOfStack > -1)

        {

            status = true;

            return arrayStack[topOfStack];

        }            

        status = false;

      

    }

    ~Stack()

    {

    }

};




void storenoMatch(noMatch **storeNoMatch, ifstream & nomatchFile  ) 
{
	string start,take;
	
	
	
	
	noMatch* newNode = new noMatch;

newNode->next = (*storeNoMatch);
    	newNode =NULL;
    	(*storeNoMatch) = newNode;
	 while (nomatchFile>>start)
{  
 
 
 noMatch* newNode = new noMatch;
 
 
//getline(nomatchFile, start, '>');

//nomatchFile>>start;



take=start.substr(1,start.length()-2);


//cout<<take;


     newNode->nomatchtag = take;
    
    	
    	newNode->next = (*storeNoMatch);
    	
    	(*storeNoMatch) = newNode;


}
	

	
}




void printAllnomatch (noMatch*  head)
{noMatch * position; 

position = head;
cout<<"check no match list:"<<endl; 
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "the list is empty"<< endl;}
else
 {while (position!=NULL)
 {
 
   cout <<position->nomatchtag<< endl;   // need setprecision to format under headings
   position = position->next;}
 }

}



Stack <string> processFile(ifstream & htmlFile, noMatch *storeNoMatch, alphabeticaTag** storeMatch, Stack <string> tagstack, ofstream &output, int i    ) 
{
		string start, word;

		
		/*	noMatch* newwNode = new noMatch;

newwNode->next = storeNoMatch;
    	newwNode =NULL;
    storeNoMatch = newwNode;*/
		
		
		
			alphabeticaTag* newNode = new alphabeticaTag;

newNode->next = (*storeMatch);
    	newNode =NULL;
    	(*storeMatch) = newNode;
	cout<<endl<<endl<<"Read from file"<<endl;	
			 while (!htmlFile.eof())
{  
getline(htmlFile, start);
cout<<start<<endl;

output<<start<<endl;

}
htmlFile.close();
if(i==1)
{
	 htmlFile.open("html1.txt");
}
if(i==2)
{
	 htmlFile.open("html2.txt");
}

       if(htmlFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}




string takenomatch[3];

noMatch * position;

position =storeNoMatch;
int y=0;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "the list is empty"<< endl;}
else
 {while (position!=NULL)
 {

takenomatch[y]=position->nomatchtag;



 position = position->next;
 y++;}











	 while (!htmlFile.eof())
{  

htmlFile>>word;



if(word.at(0)=='<')
{
unsigned first = word.find('<');
unsigned last = word.find_last_of('>');
string strNew = word.substr (first+1,last-first-1);

//takefirst=start.substr(1,start.length()-2);
cout<<"check first:"<<strNew<<endl;	













/*noMatch * position;

position =storeNoMatch;

if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "the list is empty"<< endl;}
else
 {while (position!=NULL)
 {*/
 
  // cout <<"check no match list"<< position->nomatchtag<< endl;   
   
   if(strNew==takenomatch[0]||strNew==takenomatch[1]||strNew==takenomatch[2])
   {
   	 bool same=false;
   	 
   	
   	 alphabeticaTag* nposition = new alphabeticaTag;
		nposition=(*storeMatch);

 while (nposition!=NULL)
 {
    if(nposition->nomatchTag==strNew)
    {
    	same=true;
    	nposition->nomatchcount=nposition->nomatchcount+1;
	
	}
   nposition = nposition->next;
}

alphabeticaTag* newNode = new alphabeticaTag;
   	
   	newNode->nomatchTag = strNew;
   	
   	 if(!same)
   {
   	cout<<strNew<<"not in list"<<endl;
   	
   	newNode->nomatchTag = strNew;
    	newNode->nomatchcount=1;
    	newNode->next=(*storeMatch);
    	(*storeMatch) = newNode;
   }
   	else if(same)
	   {
	   	cout<<strNew<<"already in list"<<endl;
	   	
		   }
   	
   	

   	

   	
   	
   
   	
   }
   
   
   
   
   
   else if(strNew!=takenomatch[0]&&strNew!=takenomatch[1]&&strNew!=takenomatch[2])
   {
   	

   	
   	
   	if(strNew.at(0)!='/')
   	{
   		
   		
   		
   		 bool same=false;
   	 
   	
   	 alphabeticaTag* nposition = new alphabeticaTag;
		nposition=(*storeMatch);

 while (nposition!=NULL)
 {
    if(nposition->matchTag==strNew)
    {
    	same=true;
    	nposition->matchcount=nposition->matchcount+1;
	
	}
   nposition = nposition->next;
}

alphabeticaTag* newNode = new alphabeticaTag;
   	
   	newNode->matchTag = strNew;
   	
   	if(!same)
   {
   	cout<<strNew<<"not in list"<<endl;
   	
   	newNode->matchTag = strNew;
    	newNode->matchcount=1;
    	newNode->next=(*storeMatch);
    	(*storeMatch) = newNode;
   }
   	else if(same)
	   {
	   	cout<<strNew<<"already in list"<<endl;
	   	
		   }
   	
   		

    	
    	tagstack.Push(strNew);
    	
   		
	   }
	   
	   
	   
	   
	   
   	else if(strNew.at(0)=='/')
   	{bool callStatus;
   		cout<<"The top element :"<<tagstack.Peek(callStatus)<<endl;
   		
   		
   		
   		
   		if(tagstack.Peek(callStatus)==strNew.substr(1))
   		{string x;
   			tagstack.Pop(x);
   			cout<<"remove top element from the list "<<endl; 
		   }
   		else {
   			
   			
   			cout<<"Error this tag: "<<strNew.substr(1)<<" is not at the top of the stack"<<endl;
   			
   			output<<endl<<endl<<"Error this tag: "<<strNew.substr(1)<<" is not at the top of the stack"<<endl;
   			
		   }
   		
	   }
   	
   	
   }
   
   
   
   
   
   
   
   
   	
   
   
   
   
   /*position = position->next;}*/
 }












}












































}
	

		 
	
	
	
	
	
	return tagstack;
}


void printAllmatch (alphabeticaTag*  head,ofstream &output )
{alphabeticaTag * position; 
cout<<endl<<endl<<"Finish process and print all:"<<endl<<endl;
output<<endl<<endl<<"Finish process and print all:"<<endl<<endl;
position = head;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "the list is empty"<< endl;
  output<< "the list is empty"<< endl;
  
  }
else
 {while (position!=NULL)
 {

if(position->nomatchTag!="")
{
	  cout <<"check no match list "<< position->nomatchTag<<" check count "<<position->nomatchcount<<endl; 
	  output<<"check no match list "<< position->nomatchTag<<" check count "<<position->nomatchcount<<endl; 
}

if(position->matchTag!=""&&position->matchTag!="P"&&position->matchTag!="BR"&&position->matchTag!="IMG")
{
	  cout <<"check  match list "<< position->matchTag<<" check count "<<position->matchcount<<endl; 
	  output<<"check  match list "<< position->matchTag<<" check count "<<position->matchcount<<endl; 
}

 
 
   position = position->next;}
 }

}









void freelist(noMatch** shead,alphabeticaTag** head)
{
	
	noMatch* courscurrent = *shead;
    noMatch* coursnext = NULL;
 
    while (courscurrent != NULL)
    {
        coursnext = courscurrent->next;
        free(courscurrent);
        courscurrent = coursnext;
    }
 
    
    *shead = NULL;
    
    
    
    
    	alphabeticaTag* grdcurrent = *head;
    alphabeticaTag* grdnext = NULL;
 
    while (grdcurrent != NULL)
    {
        grdnext = grdcurrent->next;
        free(grdcurrent);
        grdcurrent = grdnext;
    }
 
    
    *head = NULL;
    
    
    
    	
    
    
    
}
int main()
{
	cout<<"Welcome to HTML Tag Manager"<<endl;
	int i;
	noMatch *storeNoMatch; 
	alphabeticaTag* storeMatch;
	Stack <string> tagstack;
cout<<"Enter file name:"<<endl;
cout<<"1-html1"<<endl;
cout<<"2-html2"<<endl;
cin>>i;
    ifstream nomatchFile("nomatchFile.txt");
       if(nomatchFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	storenoMatch(&storeNoMatch,  nomatchFile  ) ;
	printAllnomatch (storeNoMatch);
	
	
	
	 nomatchFile.close();
	 
	 
	 ofstream output;
        output.open("write.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
		 ifstream  htmlFile;
		if(i==1)
{
	   htmlFile.open("html2.txt");
}
if(i==2)
{
   htmlFile.open("html2.txt");
}
	
       if(htmlFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	 
	 
	 tagstack=processFile(htmlFile, storeNoMatch, &storeMatch,  tagstack, output, i    ) ;

     printAllmatch(storeMatch, output);
	
	freelist( &storeNoMatch,&storeMatch);
	
	
	
	bool callStatus;
   	
	
	
	
	
	if(!tagstack.IsEmpty())
	{cout<<"top of stack contains:"<<tagstack.Peek(callStatus)<<endl;
		output<<"top of stack contains:"<<tagstack.Peek(callStatus)<<endl;
	}
    else
    {
    	cout<<"top of stack contains:"<<endl;
    		output<<"top of stack contains:"<<endl;
	}
	
	cout<<"Thank you for using HTML Tag Manager"<<endl;
	
	
	
	
	
	htmlFile.close();
	output.close();
	
	
	return 0;
}
