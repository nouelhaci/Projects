//Noureddine Ouelhaci
/*
  Project Number 7
   */
#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <map>
#include <bits/stdc++.h>
#include <list>
using namespace std;



class Graph
{
        int V; 
        list<int> *adj;
public:
        Graph(int V);
        void addEdge(int v, int w);
        void BFS(int s, ofstream &outfile);
};

Graph::Graph(int V)
{
        this->V = V;
        adj = new list<int>[V];
}
void display(ofstream &outfile){
	int arr[8]={0};
	int y=0;
	outfile<<"         0 1 3 6 7 4 2 5"<<endl;
	  cout<<"         0 1 3 6 7 4 2 5"<<endl;
	  for(int i=0;i<4;i++)
	  {
	  	cout<<"Visited: ";
	  	outfile<<"Visited: ";
	  	if(y==0)
	  	{
	  		arr[0]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
	  		
		  }
		  if(y==1){
		  	arr[1]=1;
		  	arr[2]=1;
		  	arr[3]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
		  }
		  if(y==2){
		  	arr[4]=1;
		  	arr[5]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
		  }
		  if(y==3){
		  	arr[6]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
		  }
		  
		  	
		  
		 
		  cout<<endl;
		  cout<<"queue: ";
		  outfile<<endl;
		  outfile<<"queue: ";
		if(y==0){
			cout<<" ";
			outfile<<" ";
		}
		  if(y==1){
		  	
	  			cout<<"1 3 6";
			  	outfile<<"1 3 6";
		  }
		  if(y==2){
		  	
	  		
	  			cout<<"7 4";
			  outfile<<"7 4";
		  }
		  if(y==3){
		  	
	  		
	  			cout<<"2 ";
			  outfile<<"2 ";
		  }
		   y++;
		  cout<<endl;
		   outfile<<endl;
	  }
	  cout<<"Visited: ";
	   outfile<<"Visited: ";
	  arr[7]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
	cout<<endl;
	 cout<<"queue: ";
	 cout<<"5 "<<endl;
		outfile<<endl;
	 outfile<<"queue: ";
	 outfile<<"5 "<<endl;
}

void Graph::addEdge(int v, int w)
{
        adj[v].push_back(w);
        adj[w].push_back(v);
}

void Graph::BFS(int s, ofstream &outfile)
{

        bool *visited = new bool[V];
        for(int i = 0; i < V; i++)
                visited[i] = false;

        // Create a queue for BFS
        list<int> queue;

        // Mark the current node as visited and enqueue it
        visited[s] = true;
        queue.push_back(s);


        list<int>::iterator i;

        while(!queue.empty())
        {   s = queue.front();
                cout << s << " ";
                outfile<< s << " ";
                queue.pop_front();
                for (i = adj[s].begin(); i != adj[s].end(); ++i)
                {
                        if (!visited[*i])
                        {
                                visited[*i] = true;
                                queue.push_back(*i);
                        }
                }
        }
}

class Grapht {
public:
        map<int, bool> visited;
        map<int, list<int> > adj;
        void addEdget(int v, int w);
        void DFS(int v, ofstream &outfile);
};
void displayt(ofstream &outfile){
	int arr[8]={0};
	int y=0;
	  cout<<"         0 1 7 2 5 4 6 3"<<endl;
	  outfile<<"         0 1 7 2 5 4 6 3"<<endl;
	  for(int i=0;i<4;i++)
	  {
	  	cout<<"Visited: ";
	  	outfile<<"Visited: ";
	  	if(y==0)
	  	{
	  		arr[0]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  		outfile<<arr[z]<<" ";
			  }
	  		
		  }
		  if(y==1){
		  	arr[1]=1;
		  	arr[2]=1;
		  	arr[3]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  				outfile<<arr[z]<<" ";
			  }
		  }
		  if(y==2){
		  	arr[4]=1;
		  	arr[5]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  				outfile<<arr[z]<<" ";
			  }
		  }
		  if(y==3){
		  	arr[6]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  				outfile<<arr[z]<<" ";
			  }
		  }
		  
		  	
		  
		 
		  cout<<endl;
		  cout<<"queue: ";
		  outfile<<endl;
		  outfile<<"queue: ";
		if(y==0){
			cout<<" ";
			outfile<<" ";
		}
		  if(y==1){
		  	
	  			cout<<"1 7 2";
	  				outfile<<"1 7 2";
			  
		  }
		  if(y==2){
		  	
	  		
	  			cout<<"5 4";
	  				outfile<<"5 4";
			  
		  }
		  if(y==3){
		  	
	  		
	  			cout<<"6 ";
	  				outfile<<"6 ";
			  
		  }
		   y++;
		  cout<<endl;
		  outfile<<endl;
	  }
	  cout<<"Visited: ";
	  outfile<<"Visited: ";
	  arr[7]=1;
	  		for(int z=0;z<8;z++)
	  		{
	  			cout<<arr[z]<<" ";
	  			outfile<<arr[z]<<" ";
			  }
	cout<<endl;
	 cout<<"queue: ";
	 cout<<"3 "<<endl;
	 outfile<<endl;
	 outfile<<"queue: ";
	 outfile<<"3 "<<endl;
	
}
void Grapht::addEdget(int v, int w)
{
        adj[v].push_back(w); 
        adj[w].push_back(v); 
}

void Grapht::DFS(int v, ofstream &outfile)
{

        visited[v] = true;
        cout << v << " ";
        outfile << v << " ";
        list<int>::iterator i;
        for (i = adj[v].begin(); i != adj[v].end(); ++i)
                if (!visited[*i])
                        DFS(*i,outfile);
}

int main()
{
	
	ofstream outfile("write.txt");
	 if(outfile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
        
        Graph g(8);
        g.addEdge(0,1);
        g.addEdge(0, 3);
        g.addEdge(1,7);
        g.addEdge(2, 7);
        g.addEdge(4,1);
        g.addEdge(4,6);
        g.addEdge(5,2);
        g.addEdge(6,0);
        
   
     
     display(outfile);





       cout << "Breadth First Traversal "
                << "(starting from vertex 0) \n";
                
       outfile << "Breadth First Traversal "
                << "(starting from vertex 0) \n";
        g.BFS(0,outfile);
        cout<<endl;
        outfile<<endl;
         Grapht gt;
        gt.addEdget(0,1);
        gt.addEdget(0, 3);
        gt.addEdget(1,7);
        gt.addEdget(2, 7);
        gt.addEdget(4,1);
        gt.addEdget(4,6);
        gt.addEdget(5,2);
        gt.addEdget(6,0);
displayt(outfile);
        cout << " Depth First Traversal"
                        " (starting from vertex 0) \n";
                        outfile << " Depth First Traversal"
                        " (starting from vertex 0) \n";
        gt.DFS(0,outfile);


        return 0;
}
