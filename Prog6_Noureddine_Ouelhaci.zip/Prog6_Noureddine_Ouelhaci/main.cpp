//Noureddine Ouelhaci
/*
  Project Number 6
   */
#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <map>
using namespace std;

#include <bits/stdc++.h>

 

#define V 6
 

#define INF 99999
 

void printSolution(int dist[][V],ofstream &outFile);
 void printpathSolution(int dist[][V], int take[][V], int k,ofstream &outFile);

void floydWarshall(int graph[][V],ofstream &outFile)
{
   
    int dist[V][V], i, j, k;
 
  int take[V][V];
  
 
    for (i = 0; i < V; i++)
        for (j = 0; j < V; j++)
            dist[i][j] = graph[i][j];
 
    for (k = 0; k < V; k++) {
       
        for (i = 0; i < V; i++) {
          
           
            for (j = 0; j < V; j++) {
                
                if (dist[i][j] > (dist[i][k] + dist[k][j])
                    && (dist[k][j] != INF
                        && dist[i][k] != INF))
                    dist[i][j] = dist[i][k] + dist[k][j];
            }
        }
        if(k==0)
        {
        	for (i = 0; i < V; i++)
        for (j = 0; j < V; j++)
        	take[i][j]=dist[i][j];
		}
        cout<<"d"<<k<<"  0          1            2            3            4            5"<<endl;
        outFile<<"d"<<k<<"  0          1            2            3            4            5"<<endl;
        printSolution(dist, outFile);
        cout<<endl;
         outFile<<endl;
        /*	cout<<"d"<<k<<"  0          1            2            3            4            5"<<endl;
        printSolution(take);
        cout<<endl;*/
        cout<<"p"<<k<<"  0          1          2          3          4          5"<<endl;
         outFile<<"p"<<k<<"  0          1          2          3          4          5"<<endl;
        printpathSolution( dist,take,k, outFile);
        cout<<endl;
        outFile<<endl;
       /* for (i = 0; i < V; i++)
        for (j = 0; j < V; j++)
        	take[i][j]=dist[i][j];*/
       
        	 
     
        
        
    }
 cout<<endl;
   outFile<<endl;
   cout << "The following matrix shows the shortest "
            "distances"
            " between every pair of vertices \n";
            outFile << "The following matrix shows the shortest "
            "distances"
            " between every pair of vertices \n";
            cout<<"df"<<"  0          1            2            3            4            5"<<endl;
             outFile<<"df"<<"  0          1            2            3            4            5"<<endl;
    printSolution(dist, outFile);
}


void printSolution(int dist[][V], ofstream &outFile)
{
   
   cout<<"--------------------------------------------------------------------"<<endl;
   outFile<<"--------------------------------------------------------------------"<<endl;
    for (int i = 0; i < V; i++) {
    	cout<<i;
    	    	outFile<<i;

        for (int j = 0; j < V; j++) {
            if (dist[i][j] == INF)
            {
			
                cout<<left<<setw(5) << "   INF"
                     << "     ";
                     outFile<<left<<setw(5) << "   INF"
                     << "     ";}
            else
            if(i==0&&j==0)
            {
            	 cout << "    "<<left<<setw(5)<<dist[i][j] << "  ";
            	 outFile << "    "<<left<<setw(5)<<dist[i][j] << "  ";
			}
			else
			{
			
                cout << "   "<<left<<setw(5)<<dist[i][j] << "     ";
                 outFile << "   "<<left<<setw(5)<<dist[i][j] << "     ";
             }
        }
        cout << endl;
          outFile << endl;
    }
}

void printpathSolution(int dist[][V], int take[][V], int k, ofstream &outFile)
{
   
  
   
   
   
   
   
   
   
   
   
   
   
   
   cout<<"--------------------------------------------------------------------"<<endl;
   outFile<<"--------------------------------------------------------------------"<<endl;
    for (int i = 0; i < V; i++) {
    	cout<<i<<"   ";
    	outFile<<i<<"   ";
        for (int j = 0; j < V; j++) {
        	if(dist[i][j] == INF||dist[i][j] == 0)
        	{
		//	if(dist[i][j]==take[i][j])
           cout<<left<<setw(11)<<"-          ";
            outFile<<left<<setw(11)<<"-          ";
          /* if(dist[i][j]!=take[i][j])
           cout<<left<<setw(11)<<k;*/
           
           
       }
            else
            {
			if(dist[i][j]==take[i][j])
			{
           cout<<left<<setw(11)<<i;
            outFile<<left<<setw(11)<<i;
       }
       	if(dist[i][j]!=take[i][j])
       	{
		   
           cout<<left<<setw(11)<<k;
          outFile<<left<<setw(11)<<k;
      }
       
}
	}
        
        cout << endl;
        outFile << endl;
    }
}


int main()
{
	
	
	
	 int graph[V][V] = { { 0, 2, 5, INF, INF,INF },
                        { INF, 0, 7, 1, INF, 8 },
                        { INF, INF, 0, 4,INF,INF },
                        { INF, INF, INF, 0, 3, INF },
                        { INF, INF, 2, INF, 0, 3 } ,
                        { INF, 5, INF, 2, 4, 0 }  };
 

	ofstream outfile("write.txt");
	 if(outfile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
 
 
 

    floydWarshall(graph, outfile);
	
	
	
	
	
		return 0;
}
