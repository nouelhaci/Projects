import socket

SERVER_PORT = 43608

def main():
    # Create a client socket and connect to the server
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    client_socket.connect(('localhost', SERVER_PORT))
    print(f"Connected to server on port {SERVER_PORT}")

    # Send commands to the server and receive responses
    while True:
        # Ask the user for a command
        command = input("Enter a command (MSGGET, MSGSTORE, QUIT, SHUTDOWN): ").upper()
        # Send the command to the server
        client_socket.sendall(command.encode())
        # Process the response from the server
        if command == "MSGGET":
            # Receive the message of the day from the server and print it
            data = client_socket.recv(1024).decode()
            response = client_socket.recv(1024).decode()
            print(response)
            print(f"Message of the day: {data}")
        elif command == "MSGSTORE":
            # Receive a response from the server and ask the user for a new message
            response = client_socket.recv(1024).decode()
            print(response)
            if response != "200 OK":
                print("Error storing message")
                break
            new_message = input("Enter new message: ")
            client_socket.sendall(new_message.encode())
            response = client_socket.recv(1024).decode()
            print(response)
        elif command == "QUIT":
            # Receive a response from the server and close the connection
            data = client_socket.recv(1024).decode()
            print(data)
            break
        elif command == "SHUTDOWN":
            # Receive a response from the server and ask for a password to shut down the server
            response = client_socket.recv(1024).decode()
            # Ask the user for a password and send it to the server
            password = input("300 PASSWORD REQUIRED: ")
            client_socket.sendall(password.encode())
            response = client_socket.recv(1024).decode()
            # Check if the password is correct before closing the connection
            if response == "200 OKAY":
                print(response)

                break
            else:
                print("301 WRONG PASSWORD")
    # Close the client socket when the loop ends
    client_socket.close()

if __name__ == "__main__":
    main()
