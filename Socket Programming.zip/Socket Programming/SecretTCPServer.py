import socket
# Create a server socket and listen for incoming connections
SERVER_PORT = 43608
MOTD = "An apple a day keeps the doctor away"
PASSWORD = "123!abc"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', SERVER_PORT))
server_socket.listen(1)
print(f"Server is listening on port {SERVER_PORT}...")
# Accept incoming connections and process client requests
while True:
    conn, addr = server_socket.accept()
    print(f"Accepted connection from {addr}")
    while True:
        # Receive data from the client
        data = conn.recv(1024).decode().strip()
        if not data:
            break
        print(f"Received data from {addr}: {data}")
        # Parse the command and execute it
        command, *args = data.split()
        if command == "MSGGET":
            # Send the message of the day to the client
            conn.sendall(MOTD.encode())
            conn.sendall(b"200 OK")
        elif command == "MSGSTORE":
            # Receive a new message from the client and store it as the message of the day
            conn.sendall(b"200 OK")
            new_motd = b""
            while True:
                chunk = conn.recv(1024)
                new_motd += chunk
                if len(chunk) < 1024:
                    break
            MOTD = new_motd.decode().strip()
            conn.sendall(b"200 OK")
        elif command == "QUIT":
            # Close the connection with the client
            conn.sendall(b"200 OK")
            conn.close()
            break
        elif command == "SHUTDOWN":
            # Ask for a password to shut down the server
            conn.sendall(b"200 OK")
            password = conn.recv(1024).decode().strip()
            if password == PASSWORD:
                conn.sendall(b"200 OKAY")
                conn.close()
                server_socket.close()
                break
            else:
                # Send wrong password message
                conn.sendall(b"301 WRONG PASSWORD")
        else:
            # Send an error response if the command is not recognized
            conn.sendall(b"400 Bad Request")
