//Noureddine Ouelhaci
/*
   Third Project
   */
   
#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <string>
#include <cstring>
#include <stack> 

using namespace std;
int fibstack(int number,ofstream &outFile)
{
	int result=0;
	int print[10][3];
	stack<int> n;
	stack<int> x;
	stack<int> y;
	int i=0;
	int take=0;
	int p=0;
	int takes;
	int g,d,ex;
		n.push(number);
		x.push(-1);
		y.push(-1);
		cout<<"n   x   y"<<endl;
		outFile<<"n   x   y"<<endl;
	while(!(y.size()==1&&y.top()!=-1))
	{
		if(x.top()==-1&&y.top()==-1)
		{
			number--;
		n.push(number);
		x.push(-1);
		y.push(-1);
		
			if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}

		if(n.top()<=1)
		{
		take=n.top();
	try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		x.push(take);	
			if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}
;	
		number=n.top();
		}
		
		}
		
		if(x.top()!=-1&&y.top()==-1)
		{
			
			number-=2;
			
			n.push(number);
		x.push(-1);
		y.push(-1);
		if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}

	if(n.top()<=1)
	{
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}		

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
		try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	y.push(number);
			
		number=n.top();	
			if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}

	}
}
		
		if(x.top()!=-1&&y.top()!=-1)
		{
		take=x.top()+y.top();
			try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	if(x.top()==-1)
	{
		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			x.push(take);
		}
		else
		{
				try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			y.push(take);	
		}

		number=n.top();	
			if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}

		}
		
	
		result=x.top()+y.top();
	
	}
		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	

		
		
		
	return result;
}

int printsteps(int number,ofstream &outFile)
{
	int result=0;
	int print[10][3];
	stack<int> n;
	stack<int> x;
	stack<int> y;
	int i=0;
	int take=0;
	int p=0;
	int takes;
	int g=9,d=0,ex;
	int count =1;
		n.push(number);
		x.push(-1);
		y.push(-1);
		print[i][0]=n.top();
		print[i][1]=x.top();
		print[i][2]=y.top();
		cout<<"n   x   y"<<endl;
		cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
        cout<<endl<<"    ("<<count<<")"<<endl<<endl;
	outFile<<"n   x   y"<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
        outFile<<endl<<"    ("<<count<<")"<<endl<<endl;

	while(!(y.size()==1&&y.top()!=-1))
	{
		if(x.top()==-1&&y.top()==-1)
		{
			number--;
		n.push(number);
		x.push(-1);
		y.push(-1);
		
			i++;
			count++;
		print[i][0]=n.top();
		print[i][1]=x.top();
		print[i][2]=y.top();
		
			cout<<"n   x   y"<<endl;
			outFile<<"n   x   y"<<endl;
			for(int k=i;k>=0;k--)
			{
				cout<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
				outFile<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
			}
			cout<<endl<<"    ("<<count<<")"<<endl<<endl;
			outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
			
		
		
		if(n.top()<=1)
		{
		take=n.top();

		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
i--;
		x.push(take);
		print[i][1]=x.top();
			count++;
				cout<<"n   x   y"<<endl;
			outFile<<"n   x   y"<<endl;
			for(int k=i;k>=0;k--)
			{
				cout<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
				outFile<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
			}
			cout<<endl<<"    ("<<count<<")"<<endl<<endl;
			outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
		number=n.top();
		}
		
		}
		
		if(x.top()!=-1&&y.top()==-1)
		{
			
			number-=2;
			
			n.push(number);
		x.push(-1);
		y.push(-1);
		i++;
		print[i][0]=n.top();
		print[i][1]=x.top();
		print[i][2]=y.top();
			count++;
				cout<<"n   x   y"<<endl;
			outFile<<"n   x   y"<<endl;
			for(int k=i;k>=0;k--)
			{
				cout<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
				outFile<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
			}
			cout<<endl<<"    ("<<count<<")"<<endl<<endl;
			outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
		
	if(n.top()<=1)
	{
			
try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	i--;
	y.push(number);
			print[i][2]=y.top();	
		number=n.top();	
		count++;
				cout<<"n   x   y"<<endl;
			outFile<<"n   x   y"<<endl;
			for(int k=i;k>=0;k--)
			{
				cout<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
				outFile<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
			}
			cout<<endl<<"    ("<<count<<")"<<endl<<endl;
			outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
	}
}
		
		if(x.top()!=-1&&y.top()!=-1)
		{
		take=x.top()+y.top();
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}


	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	i--;
	if(x.top()==-1)
	{
			try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			x.push(take);
				print[i][1]=x.top();
		}
		else
		{
		try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			y.push(take);
				print[i][2]=y.top();	
		}

		number=n.top();	
		count++;
		cout<<"n   x   y"<<endl;
			outFile<<"n   x   y"<<endl;
			for(int k=i;k>=0;k--)
			{
				cout<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
				outFile<<left<<setw(4)<<print[k][0]<<setw(4)<<print[k][1]<<setw(4)<<print[k][2]<<endl;
			}
			cout<<endl<<"    ("<<count<<")"<<endl<<endl;
			outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
		}
		
		
		result=x.top()+y.top();
		
	}
		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	count++;
	cout<<"n   x   y"<<endl;
    cout<<endl<<"    ("<<count<<")"<<endl<<endl;
	outFile<<"n   x   y"<<endl;
    outFile<<endl<<"    ("<<count<<")"<<endl<<endl;
	return result;
}
int toprecord(int number,ofstream &outFile)
{
	int result=0;
	int print[10][3];
	stack<int> n;
	stack<int> x;
	stack<int> y;
	int i=0;
	int take=0;
	int p=0;
	int takes;
	int g,d,ex;
		n.push(number);
		x.push(-1);
		y.push(-1);
		cout<<"n   x   y"<<endl;
		outFile<<"n   x   y"<<endl;
	while(!(y.size()==1&&y.top()!=-1))
	{
		if(x.top()==-1&&y.top()==-1)
		{
			number--;
		n.push(number);
		x.push(-1);
		y.push(-1);
		
		/*	if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}*/

		if(n.top()<=1)
		{
		take=n.top();
	try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		x.push(take);	
		
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	
	
		number=n.top();
		}
		
		}
		
		if(x.top()!=-1&&y.top()==-1)
		{
			
			number-=2;
			
			n.push(number);
		x.push(-1);
		y.push(-1);
	/*	if(n.top()!=-1&&x.top()!=-1&&y.top()!=-1)
			{
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	}*/

	if(n.top()<=1)
	{
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	y.push(number);
			
		number=n.top();	
			
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	

	}
}
		
		if(x.top()!=-1&&y.top()!=-1)
		{
		take=x.top()+y.top();
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	if(x.top()==-1)
	{
		try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			x.push(take);
		}
		else
		{
			try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
			y.push(take);	
		}

		number=n.top();	
			
			
			cout<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
		outFile<<left<<setw(4)<<n.top()<<setw(4)<<x.top()<<setw(4)<<y.top()<<endl;
	

		}
		
	
		result=x.top()+y.top();
	
	}
		try{
				
				if(n.empty())
				{
				throw ex;
					
				}
				n.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}

	try{
				
				if(x.empty())
				{
				throw ex;
					
				}
				x.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
	
	try{
				
				if(y.empty())
				{
				throw ex;
					
				}
				y.pop();
			}
			catch(int ex)
			{
				cout<<"The stack is empty, you cant pop it"<<endl;
				
			}
		cout<<endl;
		outFile<<endl;

		
		
		
	return result;
}

int main() {
	
	int takeresult;
		ofstream outFile("write.txt");
	 if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
        }
	cout<<"1)-Printing the most important steps:"<<endl;
	outFile<<"1)-Printing the most important steps:"<<endl;
	takeresult=fibstack(10,outFile);
	cout<<"result:"<<takeresult<<endl;
	outFile<<"result:"<<takeresult<<endl;
	
	cout<<endl<<"Printing all the steps:"<<endl;
	outFile<<endl<<"Printing all the steps:"<<endl;
takeresult=printsteps(10,outFile);
	cout<<"result:"<<takeresult<<endl;
	outFile<<"result:"<<takeresult<<endl;
	
	cout<<"3-Printing top record after we pop the stack: "<<endl;
	outFile<<"3-Printing top record after we pop the stack: "<<endl;
takeresult=toprecord(10,outFile);

	cout<<"result:"<<takeresult<<endl;
	outFile<<"result:"<<takeresult<<endl;
	
		
		
	
	
	return 0;
}
