//Noureddine Ouelhaci
/*
   Project Number Four
   */
   
#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <string>
#include <cstring>
#include <stack> 

using namespace std;
struct Node {
    int data;
    struct Node *left, *right;
};
 

Node* newNode(int data)
{
    Node* temp = new Node;
    temp->data = data;
    temp->left = temp->right = NULL;
    return temp;
}
 

void printPostorder(struct Node* node,ofstream &outFile)
{
    if (node == NULL)
        return;
 
    
    printPostorder(node->left,outFile);
 
   
    printPostorder(node->right,outFile);
 
    
    cout << node->data << " ";
    outFile<< node->data << " ";
}
 

void printInorder(struct Node* node,ofstream &outFile)
{
    if (node == NULL)
        return;

    printInorder(node->left,outFile);
 
   
    cout << node->data << " ";
    outFile << node->data << " ";
   
    printInorder(node->right,outFile);
}
 

void printPreorder(struct Node* node,ofstream &outFile)
{
    if (node == NULL)
        return;
 
    
    cout << node->data << " ";
 outFile<< node->data << " ";
  
    printPreorder(node->left,outFile);
 
  
    printPreorder(node->right,outFile);
}

void preorderIterative(Node* root,ofstream &outFile)
{
    if (root == NULL)
        return;
 
    stack<Node*> rootstack;
 
  
    Node* current = root;
 
    while (!rootstack.empty() || current != NULL) {
      
        while (current != NULL) {
           // cout << curr->data << " ";
              rootstack.push(current);
              cout << rootstack.top()->data << " ";
              outFile<< rootstack.top()->data << " ";
              rootstack.pop();
            if (current->right)
            {
			
                rootstack.push(current->right);
              
         }
       
            current = current->left;
          
         }
            
        
 
      
        if (rootstack.empty() == false) {
           
		    current = rootstack.top();
            rootstack.pop();
            
            
        }
    
    }
}




void postOrderIterative(Node* root,ofstream &outFile)
{
    if (root == NULL)
        return;
 
    
    stack<Node *> rootstack1, rootstack2;
 
    
    rootstack1.push(root);
    Node* node;
 
    
    while (!rootstack1.empty()) {
        
        node = rootstack1.top();
        rootstack1.pop();
        rootstack2.push(node);
 
     
        if (node->left)
            rootstack1.push(node->left);
        if (node->right)
            rootstack1.push(node->right);
    }
 
   
    while (!rootstack2.empty()) {
        node = rootstack2.top();
         cout << rootstack2.top()->data << " ";
         outFile<< rootstack2.top()->data << " ";
        rootstack2.pop();
       // cout << node->data << " ";
    }
}


void inOrder(struct Node *root,ofstream &outFile)
{
    stack<Node *> rootstack;
    Node *current = root;
 
    while (current != NULL || rootstack.empty() == false)
    {
       
        while (current !=  NULL)
        {
           
            rootstack.push(current);
            current = current->left;
        }
 
        current = rootstack.top();
         cout << rootstack.top()->data << " ";
         outFile<< rootstack.top()->data << " ";
        rootstack.pop();

        //cout << curr->data << " ";
 
      
        current = current->right;
 
    } 
}



int main() {
	
	struct Node* root = newNode(14);
	
		root->left = newNode(4);
    root->right = newNode(15);
    root->left->left = newNode(3);
    root->left->right = newNode(9);
    
    root->right->left = newNode(14);
    root->right->right = newNode(18);
    
    root->left->right->right = newNode(9);
    root->left->right->left = newNode(7);
    
    root->right->right->right = newNode(20);
    root->right->right->left = newNode(16);
    
    root->left->right->left->left = newNode(5);
    root->right->right->left->right = newNode(17);
    
    
    root->left->right->left->left->left = newNode(4);
    root->left->right->left->left->right= newNode(5);
    
    ofstream outFile("write.txt");
	 if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
        }
    
    
    
     cout <<endl<< "Preorder traversal of binary tree: "<<endl;
      outFile <<endl<< "Preorder traversal of binary tree: "<<endl;
    printPreorder(root,outFile);
    cout <<endl<< "Preorder traversal of binary tree using stack: "<<endl;
    outFile <<endl<< "Preorder traversal of binary tree using stack: "<<endl;
    preorderIterative(root,outFile);
    cout<<endl << "Inorder traversal of binary tree: "<<endl;
      outFile<<endl << "Inorder traversal of binary tree: "<<endl;
    printInorder(root,outFile);
    cout<<endl << "Inorder traversal of binary tree using stack: "<<endl;
    outFile<<endl << "Inorder traversal of binary tree using stack: "<<endl;
    inOrder(root,outFile);
    cout<<endl << "Postorder traversal of binary tree: "<<endl;
    outFile<<endl << "Postorder traversal of binary tree: "<<endl;
    printPostorder(root,outFile);
    cout<<endl << "Postorder traversal of binary tree using stack: "<<endl;
    outFile<<endl << "Postorder traversal of binary tree using stack: "<<endl;
    postOrderIterative(root,outFile);
	return 0;
}
