#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
#include <sstream>
using namespace std;




  
  struct student{
  
  string firstName;
  string  lastName;
  string  ID;
   string  dateOfBirth;
  double overallGPA;
  student *next;
};
  
struct course
{string courseNbr;
  string courseName;
  int creditHrs;
  course * next;
};
struct courseGrade
{ string ID;
  string  courseNbr;
  string  semester;
  char grade;
  courseGrade * next;};




void storecourse(course** courserecord)
{
int creditHrs;
string courseNbr;
string courseName; 
  ifstream courseFile("class.txt");
  if(courseFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}



    course* newNode = new course;

newNode->next = (*courserecord);
    	newNode =NULL;
    	(*courserecord) = newNode;
  while (!courseFile.eof())
{  

 course* newNode = new course;



courseFile>>courseNbr >> courseName >>creditHrs; 

//cout<<"check"<<courseNbr<<"   " << courseName<<"   " <<creditHrs;



newNode->courseNbr = courseNbr;
    	newNode->courseName=courseName;
    	
    	newNode->creditHrs=creditHrs;
    	
    	
    	newNode->next = (*courserecord);
    	
    	(*courserecord) = newNode;






 
}
  courseFile.close();
  


}



void storegrade(courseGrade** graderecord)
{
	
	char semesterLetter;
	string studentID;
  string  studentCourse;
  string  studentSemester;
  char studentGrade;
  string studentSortSemester;
  
  
  
   ifstream gradeFile("Grade.txt");
  if(gradeFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}


 
    


  while (!gradeFile.eof())
{ 
courseGrade* newNode = new courseGrade;
gradeFile>>studentID >> studentCourse >> studentSemester >> 
studentGrade;

/*cout<<"check"<<studentID << studentCourse << studentSemester << 
studentGrade;
*/



semesterLetter = studentSemester [0];  // semester character
switch(semesterLetter)  // assign sort semester based on semester character
{case 'W': 
      studentSortSemester = studentSemester.substr(1,2)+ '1'; // 2 position year + code 1
      break; 
case 'S': 
      studentSortSemester = studentSemester.substr(1,2)+ '2'; // 2 position year + code 2
      break; 
case 'F': 
      studentSortSemester = studentSemester.substr(1,2)+ '3'; // 2 position year + code 3
      break; 
}




 
newNode->ID = studentID;
newNode->courseNbr=studentCourse;
    	newNode->semester=studentSortSemester;
    	
    	newNode->grade=studentGrade;
    	
    	
    	newNode->next = (*graderecord);
    	
    	
(*graderecord) = newNode;





 
}
  gradeFile.close();
  
  
  
  
  
  
  
	
	
	
}

/*double calculateGpa(course* courserecord,courseGrade* graderecord, string id)
{
	double gpa=0;
	int total, credit=0;
	
	
	courseGrade* position = new courseGrade;
    position = graderecord;
	
	course* sposition = new course;
    sposition = courserecord;
	
	
	
	if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No grades in list"<< endl;}
else
 {while (position!=NULL)
 {

  if(position->ID==id)
    {
  
 
  
  if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (sposition!=NULL)
 {
 
 
  
  
  if(sposition->courseNbr==position->courseNbr)
    {
  
  
credit=sposition->creditHrs;
 


}
  
 
  
   sposition = sposition->next;}
 }

  
  
  switch(position->grade)  
{case 'A': 
       gpa+=4*credit;
       total+=credit;
      break; 
case 'B': 
     gpa+=3*credit;
     total+=credit;
      break; 
case 'C': 
      gpa+=2*credit;
      total+=credit;
      break; 
case 'D': 
      gpa+=1*credit;
      total+=credit;
      break;  
  
  
}
}
  

   position = position->next;}
 }



	
/*	while (position!=NULL)
 {
    if(position->ID==id)
    {
    	
    	while(sposition!=NULL)
    	{
    		
    		if(sposition->courseNbr==position->courseNbr)
    		{
    			cout<<"calculate gpa check"<<position->grade<<endl;
    			switch(position->grade)  
{case 'A': 
       gpa+=4*sposition->creditHrs;
       total+=sposition->creditHrs;
      break; 
case 'B': 
     gpa+=3*sposition->creditHrs;
     total+=sposition->creditHrs;
      break; 
case 'C': 
      gpa+=2*sposition->creditHrs;
      total+=sposition->creditHrs;
      break; 
case 'D': 
      gpa+=1*sposition->creditHrs;
      total+=sposition->creditHrs;
      break;  

}
    			
    			
    			
    			
    			
			}
    		sposition = sposition->next;
    		
		}
    	
    	
    	
    	
    	
    	
	
	}
   position = position->next;
}
	
	
	
	
	
	
	
	
	
	
	gpa=gpa/total;
	
	cout<<"check gpa"<<gpa;
	
	
	
	
	return gpa;
}*/


void storstudent(student** studentrecord )
{
	

string studentFirstName;
string studentLastName;  
string studentID;
string studentBirthDay;
  double overallgpa;





 ifstream studentFile("student.txt");
  if(studentFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}



    student* newNode = new student;

	newNode->next = (*studentrecord);
    newNode=NULL;
    	(*studentrecord) = newNode;
  while (!studentFile.eof())
{  

student* newNode = new student;

	
studentFile >> studentFirstName >>studentLastName >> studentID >> 
studentBirthDay; 



newNode->firstName = studentFirstName;
newNode->lastName=studentLastName;
    	newNode->ID=studentID;
    	
    	newNode->dateOfBirth=studentBirthDay;

    	
    	
    	newNode->next = (*studentrecord);
   
    	(*studentrecord) = newNode;








}

  studentFile.close();



	
}
void printAllCourse (course*  head)
{course * position; 
cout << "studentID    courseNumber    semester     sortSemester    Grade" << endl;
position = head;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No grades in list"<< endl;}
else
 {while (position!=NULL)
 {
 
   cout <<"check courses"<< position->courseNbr<<" "<<position->courseName<<" " <<position->creditHrs<< endl;   // need setprecision to format under headings
   position = position->next;}
 }

}


void printAllCourseGrade (courseGrade * head)
{





courseGrade * position; 
cout << "studentID    courseNumber    semester     sortSemester    Grade" << endl;
position = head;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No grades in list"<< endl;}
else
 {while (position!=NULL)
 {
 
   cout << position-> ID<<" " << position-> courseNbr  << " " 
   << position-> semester  << " " 
   << position-> grade << endl;   // need setprecision to format under headings
   position = position->next;}
 }

}





void printAllstudentrecord (student * head)
{




student * Sposition; 
cout << "First name    Last name    studentID     Date of Birth   overallGpa" << endl;
Sposition = head;
if (Sposition == NULL)    // handle situation list is empty (test case!)
  { cout << "No grades in list"<< endl;}
else
 {while (Sposition!=NULL)
 {

 
   cout << Sposition->firstName<<" " << Sposition-> lastName  << " " 
   << Sposition-> ID  << " " 
   << Sposition-> dateOfBirth<<"  "<<Sposition->overallGPA<< endl;  
    // need setprecision to format under headings
   Sposition = Sposition->next;}
 }

}






void searchstudentid (student * head, string id)
{student * position; 



bool check=false;

cout << "First name    Last name    studentID     Date of Birth   overallGpa" << endl;
position = head;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (position!=NULL)
 {
 
 
 
 
 if(position->ID==id){
 
   cout << position->firstName<<" " << position-> lastName  << " " 
   << position-> ID  << " " 
   << position-> dateOfBirth<<"  "<<position->overallGPA<< endl; 
   check=true;  // need setprecision to format under headings
}
   
   
   
   
   position = position->next;
 }




}
if(check==false)
{
	
	cout<<"student ID not found"<<endl;
}
}


void searchcourserecord(courseGrade * head, string coursNM)
{
bool check=false;

courseGrade * position; 
cout << "studentID    courseNumber    semester     sortSemester    Grade" << endl;
position = head;
if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (position!=NULL)
 {
 
 
 
 
     if(position->courseNbr==coursNM){
 
   cout << position-> ID<<" " << position-> courseNbr  << " " 
   << position-> semester  << " " 
   << position-> grade << endl; 
   check=true;
   
    }
   position = position->next;}
}
if(check==false)
{
	
	cout<<"cours number not found"<<endl;
}
}








void addcoursedata(course** head_ref)
{
  int creditHrs;
string courseNbr;
string courseName;
cout<<"enter credit hours:";
cin>>creditHrs;
cin.clear();
			cin.ignore(1000, '\n');
cout<<"enter course Number:";
getline(cin,courseNbr);

cout<<"enter course Name:";

  getline(cin,courseName);
  
  
  
  
  
  
  
  
     course* new_node = new course();
 new_node->next = (*head_ref);
  
  
  
  
     bool same=false;
   course* position = new course;
		position=(*head_ref);

 while (position!=NULL)
 {
    if(position->courseNbr==courseNbr)
    {
    	same=true;
    	
	
	}
   position = position->next;
}
 

   if(!same)
   {
   	cout<<courseNbr<<"not in list"<<endl;
   	 
    new_node->creditHrs = creditHrs;
    new_node->courseNbr = courseNbr;
    new_node->courseName = courseName;
 
    
    
 
    
    (*head_ref) = new_node;
   }
   	else if(same)
	   {
	   	cout<<courseNbr<<"already in list"<<endl;
	   
		   }
  
  
  
  
 
 
}


void addstudentdata(student** head_ref)
{
   
   string studentFirstName;
string studentLastName;  
string studentID;
string studentBirthDay;
   
   
   
   
   cin.clear();
			cin.ignore(1000, '\n');
   cout<<"enter student First Name:";
getline(cin,studentFirstName);

cout<<"enter student Last Name:";

  getline(cin,studentLastName);
  cout<<"enter student ID";
getline(cin,studentID);

cout<<"enter student BirthDay:";

  getline(cin,studentBirthDay);
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   
   

    student* new_node = new student();
  new_node->next = (*head_ref);
    
   /* new_node->firstName = studentFirstName;
    new_node->lastName = studentLastName;
    new_node->ID = studentID;
    new_node->dateOfBirth = studentBirthDay;*/
 
   
   
 
    
   // (*head_ref) = new_node;
    
    
     bool same=false;
   student* position = new student;
		position=(*head_ref);

 while (position!=NULL)
 {
    if(position->ID==studentID)
    {
    	same=true;
    	
	
	}
   position = position->next;
}
 

   if(!same)
   {
   	cout<<studentID<<"not in list"<<endl;
   	 new_node->firstName = studentFirstName;
    new_node->lastName = studentLastName;
    new_node->ID = studentID;
    new_node->dateOfBirth = studentBirthDay;
 
   
   
 
    
    (*head_ref) = new_node;
   }
   	else if(same)
	   {
	   	cout<<studentID<<"already in list"<<endl;
	   
		   }
    
    
    
    
    
    
   
}
void addcoursegradedata(courseGrade** head_ref)
{
   
   
   char semesterLetter;
	string studentID;
  string  studentCourse;
  string  studentSemester;
  char studentGrade;
  string studentSortSemester;
   
   cin.clear();
			cin.ignore(1000, '\n');
    cout<<"enter student ID:";
getline(cin,studentID);

cout<<"enter student Course:";

  getline(cin,studentCourse);
  cout<<"enter student Semester";
getline(cin,studentSemester);


while(studentSemester[0]!='W'&&studentSemester[0]!='F'&&studentSemester[0]!='S')
  {
  	cout<<"invalide data. Try again"<<endl;
  cout<<"enter student Semester";
getline(cin,studentSemester);
  	
  	
  	
  }
cout<<"enter student Grade letter:";

  cin>>studentGrade;
  
  while(studentGrade!='A'&&studentGrade!='B'&&studentGrade!='C'&&studentGrade!='D'&&studentGrade!='E'&&studentGrade!='F')
  {
  	cout<<"invalide data. Try again"<<endl;
  	cout<<"enter student Grade letter:";

  cin>>studentGrade;
  	
  	
  	
  }
   
   studentGrade=toupper(studentGrade);
   
   
    courseGrade* new_node = new courseGrade();
 new_node->next = (*head_ref);





  bool samesort=false;
   courseGrade* positionsort = new courseGrade;
		positionsort=(*head_ref);

 while (positionsort!=NULL)
 {
    if(positionsort->courseNbr==studentCourse&&positionsort->ID==studentID)
    {
    	samesort=true;
    
	
	}
   positionsort = positionsort->next;
}
 

   if(!samesort)
   {
   		cout<<studentCourse<<" and "<<studentID<<"not in list"<<endl;
   	    new_node->ID = studentID;
    new_node->courseNbr = studentCourse;
    new_node->grade = studentGrade;
    
    
    
    semesterLetter = studentSemester [0];  // semester character
switch(semesterLetter)  // assign sort semester based on semester character
{case 'W': 
      studentSortSemester = studentSemester.substr(1,2)+ '1'; // 2 position year + code 1
      break; 
case 'S': 
      studentSortSemester = studentSemester.substr(1,2)+ '2'; // 2 position year + code 2
      break; 
case 'F': 
      studentSortSemester = studentSemester.substr(1,2)+ '3'; // 2 position year + code 3
      break; 
}
    
    
    
    
    
    new_node->semester = studentSortSemester;
 
    
 
    
    (*head_ref) = new_node;
   }


else if(samesort)
	   {
	   	cout<<studentCourse<<" and "<<studentID<<"already in list"<<endl;
	   	
		   }



}








void displaytranscrept(student* studentrecord,course* courserecord,courseGrade* graderecord, string id)
{
	double semestergpa;
	int totalcredit;
	student * stdposition; 

stdposition = studentrecord;

string take;





char takevalue;



	
	
	bool check=false;


if (stdposition == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (stdposition!=NULL)
 {
 	
 	
 	if(stdposition->ID==id){
 
    cout<< stdposition-> firstName<<" " << stdposition-> lastName <<endl; 
   cout << stdposition-> ID<<endl;
   courseGrade * grdposition; 

grdposition = graderecord;
      if (grdposition == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (grdposition!=NULL)
   {
   	course * courseposition; 

courseposition = courserecord;
  // cout<<"CHECKCHAR "<<grdposition->ID;
   
   
   if(grdposition->ID==stdposition->ID)
   {
   	take=grdposition->semester;
   	takevalue=take[2];
   	
   	
   	switch(takevalue)  
{case '1': 
          	cout<<"Winter";
      break; 
case '2': 
     cout<<"Summer";
      break; 
case '3': 
      	cout<<"Fall";
      break; 
  

}
   	
   	
   	
  
   
   cout<<" 20"<<take.substr(0,2)<<endl;
   
   cout<<grdposition->courseNbr<<" ";
 	

 	course * courseposition; 

courseposition = courserecord;
 	
 	if (courseposition == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (courseposition!=NULL)
 {
 
 
   if(courseposition->courseNbr==grdposition->courseNbr)
   {
   	cout<<courseposition->courseName<<" "<<courseposition->creditHrs<<" ";
   	
   	   			switch(grdposition->grade)  
{case 'A': 
       semestergpa+=4*courseposition->creditHrs;
       totalcredit+=courseposition->creditHrs;
      break; 
case 'B': 
     semestergpa+=3*courseposition->creditHrs;
     totalcredit+=courseposition->creditHrs;
      break; 
case 'C': 
      semestergpa+=2*courseposition->creditHrs;
      totalcredit+=courseposition->creditHrs;
      break; 
case 'D': 
      semestergpa+=1*courseposition->creditHrs;
      totalcredit+=courseposition->creditHrs;
      break;  

}
 	cout<<grdposition->grade<<endl;
	 semestergpa=semestergpa/totalcredit;
	 cout<<"Semester GPA      "<<semestergpa<<endl;
   semestergpa=0;	
   totalcredit=0;
}
 	

   
   	
 	
 
 	 courseposition = courseposition->next;
 }

}
}
 
 	
 	
 
   grdposition = grdposition->next;
}

}
 	

 	
 	check=true;
 	
 }
 	

 	
 	    
cout<<"OverallGPA: "<<stdposition->overallGPA<<endl;
   stdposition = stdposition->next;
}
}

if(check==true)
{
	
	cout<<"Overall GPA        "<<stdposition->overallGPA<<endl;
}


if(check==false)
{
	
	cout<<"student id not found"<<endl;
}

}
	






void updategpa(course* courserecord,courseGrade* graderecord,student** studentrecord )
{
	double overallgpa=0;
	int totalcredit=0;


	

	student* position = (*studentrecord);

	
	
	
	
	if (position == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (position!=NULL)
 {
 	overallgpa=0;
 	totalcredit=0;
 courseGrade * grdposition; 

grdposition = graderecord;
 
       if (grdposition == NULL)    // handle situation list is empty (test case!)
  { /*cout << "No data in list"<< endl;*/}
else
 {while (grdposition!=NULL)
 {
 	
 	if(grdposition->ID==position->ID)
 	{
 			course * courseposition; 

courseposition = courserecord;
 		
 		if (courseposition == NULL)    // handle situation list is empty (test case!)
  { cout << "No data in list"<< endl;}
else
 {while (courseposition!=NULL)
 {
 	
	 if(courseposition->courseNbr==grdposition->courseNbr)
	 {
	 	
	 	
	 	
	 	
	 	
	 	
	 	
	 		switch(grdposition->grade)  
{case 'A': 
       overallgpa+=4*courseposition->creditHrs;
       totalcredit+=courseposition->creditHrs;
      break; 
case 'B': 
     overallgpa+=3*courseposition->creditHrs;
     totalcredit+=courseposition->creditHrs;
      break; 
case 'C': 
      overallgpa+=2*courseposition->creditHrs;
      totalcredit+=courseposition->creditHrs;
      break; 
case 'D': 
      overallgpa+=1*courseposition->creditHrs;
      totalcredit+=courseposition->creditHrs;
      break;  

}
	 	
	 	

	 	
	 	
	 	
	 }
	 
	 
	 
	 
	 	
 		
 		
 	courseposition=courseposition->next;	
 	}
 		
 		
	 }
 	
 	
 
 	
 }
 grdposition=grdposition->next;
 
}
 }
 
 

 
 	/*overallgpa=calculateGpa(courserecord,graderecord,position->ID  );
    	
    		position->overallGPA=overallgpa;*/
 
 
 
 
 
 
 position->overallGPA=overallgpa/totalcredit;
 
 
 position=position->next;
}
}



}

void freelist(course** courserecord,courseGrade** graderecord,student** studentrecord)
{
	
	course* courscurrent = *courserecord;
    course* coursnext = NULL;
 
    while (courscurrent != NULL)
    {
        coursnext = courscurrent->next;
        free(courscurrent);
        courscurrent = coursnext;
    }
 
    
    *courserecord = NULL;
    
    
    
    
    	courseGrade* grdcurrent = *graderecord;
    courseGrade* grdnext = NULL;
 
    while (grdcurrent != NULL)
    {
        grdnext = grdcurrent->next;
        free(grdcurrent);
        grdcurrent = grdnext;
    }
 
    
    *graderecord = NULL;
    
    
    
    	student* stdcurrent = *studentrecord;
    student* stdnext = NULL;
 
    while (stdcurrent != NULL)
    {
        stdnext = stdcurrent->next;
        free(stdcurrent);
        stdcurrent = stdnext;
    }
 
    
    *studentrecord = NULL;
    
    
    
    
}
	
	
	
	


















int main() {
	
	
	cout<<"Welcome to Student Records Manager"<<endl;
	int choose;
	string id;
	string coursNM;
	student* studentrecord;
	course* courserecord;
	courseGrade* graderecord;
	
	storecourse(&courserecord);
	//printAllCourse (courserecord);
	
	storegrade(&graderecord);
	storstudent(&studentrecord);
	updategpa( courserecord, graderecord, &studentrecord );
//	printAllCourseGrade(graderecord);*/
	cout<<"choose frome the menu:(1-10)"<<endl;
	cout<<"1.    Display all student records:"<<endl;
	cout<<"2.    Display all course records "<<endl;
	cout<<"3.    Search for student(ID)   "<<endl;
	cout<<"4.    Search for course record (Course Nbr)"<<endl;
	cout<<"5  .  Enter new course data "<<endl;
	
	cout<<"6.    Enter new student data"<<endl;
	cout<<"7.    Enter new course grade data"<<endl;
	
	cout<<"8.    Create transcript for student (ID)"<<endl;
	cout<<"9.    Update overall GPA's "<<endl;
	cout<<"10.  Free lists"<<endl;
	cout<<"0.  to quite"<<endl;
	cin>>choose;
	
	

	while(choose!=0)
	{
		
		
		if(choose==1)
		{
			printAllstudentrecord (studentrecord);
			
		}
		if(choose==2)
		{
			
			printAllCourseGrade (graderecord);
			
		}
		if(choose==3)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout<<"enter student id:";
			getline(cin, id);
			searchstudentid (studentrecord,  id);
			
		}
		if(choose==4)
		{
			cin.clear();
			cin.ignore(1000, '\n');
			cout<<"enter student course number:";
			getline(cin, coursNM);
			searchcourserecord(graderecord,  coursNM);
		}
		if(choose==5)
		{
			addcoursedata(&courserecord);
			updategpa( courserecord, graderecord, &studentrecord );
		}
		if(choose==6)
		{
			addstudentdata(&studentrecord);
			updategpa( courserecord, graderecord, &studentrecord );
		}
		if(choose==7)
		{
			
			addcoursegradedata(&graderecord);
			updategpa( courserecord, graderecord, &studentrecord );
		}
		if(choose==8)
		{cin.clear();
			cin.ignore(1000, '\n');
			cout<<"enter student id:";
			getline(cin, id);
			displaytranscrept( studentrecord,courserecord, graderecord,  id);
			
		}
		if(choose==9)
		{
			updategpa( courserecord, graderecord, &studentrecord );
			
		}
		if(choose==10)
		{
			freelist(&courserecord, &graderecord,&studentrecord);
			
		}
		
	
		
		
		
		
			if(choose>10||choose<0)
	{
		cout<<"invalid input.Try again."<<endl;
		

	}
		
		
	cout<<"choose frome the menu:(1-10)"<<endl;
	cout<<"1.    Display all student records:"<<endl;
	cout<<"2.    Display all course records "<<endl;
	cout<<"3.    Search for student(ID)   "<<endl;
	cout<<"4.    Search for course record (Course Nbr)"<<endl;
	cout<<"5  .  Enter new course data "<<endl;
	
	cout<<"6.    Enter new student data"<<endl;
	cout<<"7.    Enter new course grade data"<<endl;
	
	cout<<"8.    Create transcript for student (ID)"<<endl;
	cout<<"9.    Update overall GPA's "<<endl;
	cout<<"10.  Free lists"<<endl;
	cout<<"0.  to quite"<<endl;
	cin>>choose;
	
	
	
		
		
	}
	
	
	cout<<"Thank you for using Student Records Manager"<<endl;
	
	
	return 0;
}
