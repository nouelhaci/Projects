// Lab 6 
/*
   Noureddine Ouelhaci
   The random access file program
   October 17,2021
*/

#include <iostream>
#include <fstream>
#include <iomanip>
using namespace std;

struct clientData {
    int accountNumber;
    char lastName[15];
    char firstName[10];
    float balance;
};

int main() {
    cout<<"Welcome to the random access file program"<<endl;
    ofstream outCredit("credit.dat", ios::out);
    clientData blankClient = { 0, "", "", 0.0 };
    cout<<"Initialized random access file with 100 records"<<endl;
    for (int i = 0; i < 100; i++)
        outCredit.write(reinterpret_cast<char*> (&blankClient), sizeof(clientData));

    outCredit.close();


   
    clientData client;
    ofstream outCredit1("credit.dat", ios::ate);

    cout << "Enter account number between 1-100 (choose 0 to quit): ";
    cin >> client.accountNumber;

    while (client.accountNumber != 0)
    {
        if (client.accountNumber < 1 || client.accountNumber > 100)
            cout << "Invalid data. Try again" << endl;
        else {
            cout << "Enter your firstname: ";
            cin >> client.firstName;
            cout << "Enter your lastname: ";
            cin >> client.lastName;
            cout << "Enter your balance: ";
            cin >> client.balance;
            outCredit1.seekp((client.accountNumber - 1) * sizeof(clientData));
            outCredit1.write(reinterpret_cast <char*>(&client), sizeof(clientData));
        }

        cout << endl << "Enter account number between 1-100 (choose 0 to quit): ";
        cin >> client.accountNumber;

    }

    outCredit1.close();

int x;
    cout << endl;
    cout <<"Display account numbers information: " << endl;
    ifstream inCredit("credit.dat", ios::in);

    cout << "Enter account number between 1-100 (choose 0 to quit): ";
    cin >> x;

    cout << fixed<<showpoint << setprecision(2);
    while (x != 0)
    {
        if (x < 1 || x> 100)
            cout << "Invalid data. Try again" << endl;
        else {
            inCredit.seekg((x - 1) * sizeof(clientData));
            inCredit.read(reinterpret_cast<char*>(&client), sizeof(clientData));
           
			if(client.accountNumber==0)
			{
				cout<<"   "<<x<<"   ";
				cout<<"    does not exist � account number in file is zero      "<<endl;
			}
			else
			{
			
            cout << "Account Number: " << client.accountNumber << endl;
            cout << "First name: " << client.firstName << endl;
            cout << "Last name: " << client.lastName << endl;
            cout << "Balance: $" << client.balance << endl;
    }
        }

        cout << endl << "Enter account number between 1-100 (choose 0 to quit): ";
        cin >> x;

    }



  
    inCredit.clear();
    inCredit.seekg(0);
    inCredit.read(reinterpret_cast<char*>(&client), sizeof(clientData));
    cout << "The list of existed account" << endl;
    cout << left << setw(20) << "Account Number" << setw(25) << "First Name" << setw(25) << "Last Name" << setw(15) << "Balance" << endl;
    while (inCredit && !inCredit.eof()) {
        if (client.accountNumber != 0) {
            cout << left << setw(20) << client.accountNumber << setw(25) << client.firstName
                << setw(25) << client.lastName << setw(15) << client.balance << endl;
        }
        inCredit.read(reinterpret_cast<char*>(&client), sizeof(clientData));
    }

    inCredit.close();
   
cout<<"Thank you for using the random access file program"<<endl;
    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
