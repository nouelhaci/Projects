// Lab 3 project 1
/*
   Noureddine Ouelhaci
   program that computes the square root of a user's input to an accuracy of 0.0001 
   September 29,2021
*/






#include <iostream>
#include <assert.h>
#include <string>
using namespace std;

void assertThis( double x);
double squareRoot( double x);
char getSentinel();
int main(){


     double inputValue=0, squareRootvalue=0; 
     char sentinel= 'y';
     while(sentinel=='y'||sentinel=='Y'){
     	
     	
     	cout<<"Enter the value you want to find the square root of:";
     	cin>>inputValue;
     	
     	assertThis( inputValue);
     	squareRootvalue=squareRoot(  inputValue);
     	cout<<"The square root of "<<inputValue<<" is "<<squareRootvalue<<endl;
     	
     	
     	sentinel=getSentinel();
     	
     	
     	
     	
     	
     	
     	
     	
     	
     	
	 }
     
     
     
   
   return 0;
}


void assertThis( double x)// it will assert that the user input is an non-zero positive integer
{
	
	assert(x>0 && "error message: value less than or equal to 0 " );

 } 
double squareRoot( double x)// it will accept the user input and calculate the square root of it.
{
	double xSubN=0,xNPlusOne=0;
	
	xSubN=x/2;
	xNPlusOne=(xSubN+(x/xSubN))/2;
	while((xSubN - xNPlusOne)>0.0001 ){
		xSubN= xNPlusOne;
		xNPlusOne= (xSubN+(x/xSubN))/2;
	}
	
	
	return xNPlusOne;
	
}
char getSentinel()//it will ask the users if they want to continue and return the answer as char 
{
	char userInput='n';
	string take;
	bool inputCheck=false;
	cin.clear();
			cin.ignore(1000, '\n'); 
	cout<<"Do you wish to determine the square root of another number (y/n)?";
	getline(cin,take);
	userInput=take.at(0);
	do
	{
		if( userInput=='y'||userInput=='Y'||userInput=='n'||userInput=='N' )
		{
			inputCheck=true;
		}
		else
		{
			
			cout<<"Invalid response:"<<userInput<<endl;
		//	cin.clear();
			cout<<"Do you wish to determine the square root of another number (y/n)?";
	        getline(cin,take);
	        userInput=take.at(0);
		}
		
		
		
	}while(inputCheck ==false);
	
	return userInput;
}
