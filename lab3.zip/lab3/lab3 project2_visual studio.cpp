// Lab 3 project 2
/*
   Noureddine Ouelhaci
   program that reads a given file and stores its contents then print the file's contents and how many numbers it contained
   September 29,2021
*/






#include <iostream>
#include <fstream>
#include <string>
#include <assert.h>
using namespace std;

#define SIZE  20
char getSentinel();
void readIntFile( ifstream &x, int intArray [ ], int size, int &length );
void printFileValues(int intArray [ ], int &length);
int main(){

    ifstream inputStream;
    
    
    const int size=SIZE;  
    
    string fileName= "Null"; 
    
    int length =0;
    
    bool isEmpty =false; 
    
    int intArray[SIZE];   
    
    char sentinel= 'y';
    while(sentinel=='y'||sentinel=='Y')
    {
    	
    	
    	
		
    	while(!inputStream.is_open())
    	{
    	
    	cout<<"Please enter the name of the file: ";
    	
		getline(cin,fileName); 
		
    	inputStream.open(fileName);
			
    	if(inputStream.fail())
    	{
    		cout<<"Error,"<<fileName<<" is Invalid File Name."	<<endl;
		}
    	
		}
	
    	isEmpty=( inputStream.get(), inputStream.eof() );
    	cout<< fileName <<" is "<< ( isEmpty ? "" : "not " ) << "empty\n";
    	if(isEmpty==true)
    	{
    		cout<<"Error,"<<fileName<<" has no data"<<endl;
		}
   
    	 
		 
		 
		 
		 if(isEmpty==false&&!inputStream.fail())
    	{
    		
    		readIntFile( inputStream,  intArray,  size,  length );
    		printFileValues( intArray ,  length);
    		
    		
    		
		}
		
		
		
		
		
		
		inputStream.close();
		
		sentinel= getSentinel();
		/*cin.clear();
			cin.ignore(1000, '\n');*/
		
		
		
		
	}
    
    
    
    
    
    
     
     
     
   
   return 0;
}
//it will read the file and determine the size of it
void readIntFile( ifstream &x, int intArray [ ], int size, int &length ){


   int count =0;
   int arrayLocation =-1;
   int fileInputValue =0;
   x>>fileInputValue;
  // cout<<"your value"<<fileInputValue;
   
   while((!x.eof())/*&&(count<=size)*/)
   {
   	
   	 //cout<<"your value"<<fileInputValue;
   	 count++;
   	 if(count>size)
   {
   	
   	cout<<"The file has more than "<<size<<"  values"<<endl;
   	
   	
   	break;
   }
   arrayLocation++;
   intArray [arrayLocation]=fileInputValue;
   length=count;
   x>>fileInputValue;
   }
   
 //cout<<"count"<<count<<endl;
   



}











//it will ask the users if they want to continue and return the answer as char 
char getSentinel()
{
	char userInput='n';
	string take;
	bool inputCheck=false; 
	/*cin.clear();
			cin.ignore(1000, '\n');*/
	cout<<endl<<"Do you wish to process another file (y/n)?";
	getline(cin,take);
	userInput=take.at(0);
	
	do
	{
		if( userInput=='y'||userInput=='Y'||userInput=='n'||userInput=='N' )
		{
			inputCheck=true;
		}
		else
		{
			
			cout<<endl<<"Invalid response:"<<userInput<<endl;
			
			cout<<"Do you wish to process another file (y/n)?";
	      getline(cin,take);
	     userInput=take.at(0);
		}
		
		
		
	}while(inputCheck ==false);
	
	return userInput;
}
//it will assert that the file is not empty and print the file's contents and how many numbers it contained
void printFileValues(int intArray [ ], int &length){


assert(length>0 && "error message: value less than or equal to 0 " );

cout<<length<<" values processed from the file."<<endl<<" The values are: ";
    
    for(int x=0;x<length-1;x++)
    {
    	cout<<intArray [x ]<<", ";
	}
    	cout<<intArray [length-1 ];






}
