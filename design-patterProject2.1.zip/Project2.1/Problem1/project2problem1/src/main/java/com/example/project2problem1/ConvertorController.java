package com.example.project2problem1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.scene.control.TextField;


// "ConvertHandler"
abstract class ConvertHandler
{
    protected ConvertHandler successor;
    public void SetSuccessor(ConvertHandler successor)
    {
        this.successor = successor;
    }
    public abstract double HandleRequest(String UserInput, double userinput);
}

// "MILE_Handler"
class MILE_Handler extends ConvertHandler
{
    @Override public  double HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Mile"))
        {
            System.out.println("Mile");


            userinput=userinput*0.621371;
            System.out.println(userinput);

            return userinput;
        }
        else
        {
          return   successor.HandleRequest(UserInput, userinput);
        }

    }
}

// "YARD_Handler"
class YARD_Handler extends ConvertHandler
{
    @Override public  double HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Yard"))
        {
            System.out.println("Yard");
            userinput= userinput*1093.61;
            System.out.println(userinput);
            return userinput;
        }
        else
        {
           return successor.HandleRequest(UserInput, userinput);
        }

    }
}

// "FOOT_Handler"
class FOOT_Handler extends ConvertHandler
{
    @Override public  double HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Foot"))
        {
            System.out.println("Foot");
            userinput= userinput*3280.84;
            System.out.println(userinput);
            return userinput;
        }
        else
        {
           return successor.HandleRequest(UserInput, userinput);
        }

    }
}










public class ConvertorController implements Initializable {
    @FXML
    private TextField userinput;

    @FXML
    private TextField useroutput;

    @FXML
    private Button convertw;


    @FXML
    private ChoiceBox unit;

    private String[] units={"Mile", "Yard", "Foot"};
    @Override
    public  void initialize(URL arg1, ResourceBundle arg2) {
        unit.getItems().addAll(units);
        unit.setValue("--Select--");
    }

    public void convertonAction(ActionEvent actionEvent) throws Exception {



        ConvertHandler mile_handler = new MILE_Handler();
        ConvertHandler yard_handler = new YARD_Handler();
        ConvertHandler foot_handler = new FOOT_Handler();
        mile_handler.SetSuccessor(yard_handler);
        yard_handler.SetSuccessor(foot_handler);

        useroutput.setText(String.valueOf(mile_handler.HandleRequest(unit.getValue().toString(),
                Double.parseDouble(userinput.getText()))));



    }


}