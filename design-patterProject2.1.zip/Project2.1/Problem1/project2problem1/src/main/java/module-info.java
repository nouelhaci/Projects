module com.example.project2problem1 {
    requires  javafx.graphics;
    requires  javafx.fxml;
    requires  javafx.controls;
    requires  java.sql;
    requires java.datatransfer;
    requires java.desktop;

    opens com.example.project2problem1;

   /* opens com.example.project2problem1 to javafx.fxml;
    exports com.example.project2problem1;*/
}