package com.example.project2problem1;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;

import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Formatter;
import java.util.ResourceBundle;

import javafx.scene.control.TextField;











// "ConvertHandler"
abstract class ConvertHandler
{
    protected ConvertHandler successor;
    public void SetSuccessor(ConvertHandler successor)
    {
        this.successor = successor;
    }
    public abstract  String HandleRequest(String UserInput, double userinput);
}

// "MILE_Handler"
class MILE_Handler extends ConvertHandler
{
    @Override public String HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Mile"))
        {
            System.out.println("Mile");


            userinput=userinput*0.621371;
            System.out.println(userinput);


            return Double.toString(userinput);
        }
        else 
        {
           return successor.HandleRequest(UserInput, userinput);

        }

    }
}

// "YARD_Handler"
class YARD_Handler extends ConvertHandler
{
    @Override public String HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Yard"))
        {
            System.out.println("Yard");
            userinput= userinput*1093.61;
            System.out.println(userinput);
            return Double.toString(userinput);
        }
        else
        {
           return successor.HandleRequest(UserInput, userinput);
        }

    }
}

// "FOOT_Handler"
class FOOT_Handler extends ConvertHandler
{
    @Override public String HandleRequest(String UserInput, double userinput)
    {
        if (UserInput.equals("Foot"))
        {
            System.out.println("Foot");
            userinput= userinput*3280.84;
            System.out.println(userinput);
            return Double.toString(userinput);
        }
        else
        {
            return successor.HandleRequest(UserInput, userinput);
        }

    }
}










abstract class Decorator extends  ConvertHandler
{


    @Override public abstract String HandleRequest(String UserInput, double userinput);
}



 class Decimal  extends Decorator

{
    private ConvertHandler successor;
    public Decimal(ConvertHandler successor)
    {
        this.successor = successor;
    }


   @Override public  String HandleRequest(String UserInput, double userinput)
    {
        String token = successor.HandleRequest(UserInput, userinput);
        System.out.println("check 1 "+token);
        Formatter formatter = new Formatter();
        formatter.format("%.2f", Double.parseDouble(token));
       /* decimal newToken = decimal.Parse(token);
        String output = newToken.ToString("F2");*/
        return String.valueOf(formatter);
        /*Formatter formatter = new Formatter();
        formatter.format("%.2f", userinput);

        return String.valueOf(formatter);*/
    }

}


class Expnotation  extends Decorator
{


    private ConvertHandler successor;
    public Expnotation(ConvertHandler successor)
    {
        this.successor = successor;


    }




    @Override public  String HandleRequest(String UserInput, double userinput)
    {System.out.println("check 2 "+UserInput+userinput);
        String token = successor.HandleRequest(UserInput, userinput);
      //  System.out.println("check "+token);
        NumberFormat formatter = new DecimalFormat("0.#########E0");


        return String.valueOf(formatter.format(Double.parseDouble(token) ).toLowerCase());
// We first delegate the call to the object we are decorating, so that it can
//compute the cost; then add the cost of Mocha to that result.
    }


}


class UnitName extends Decorator
{
    // Mocha is a decorator, so we extend condimentDecorator
// remember, CondimentDeorator extend Beverage
    private ConvertHandler successor;
    public UnitName(ConvertHandler successor)
    {
        this.successor = successor;


    }
    @Override public  String HandleRequest(String UserInput, double userinput)
    {


        String token = successor.HandleRequest(UserInput, userinput).toString();

        if(UserInput.equals("Mile"))
        {
            UserInput="Miles";
        }
        else if(UserInput.equals("Yard")) {
            UserInput="Yards";
        }
        else if(UserInput.equals("Foot")) {
            UserInput="Feet";
        }
        return token+" " +UserInput;
// We first delegate the call to the object we are decorating, so that it can
//compute the cost; then add the cost of Mocha to that result.
    }


}











public class ConvertorController implements Initializable {
    @FXML
    private TextField userinput;

    @FXML
    private TextField useroutput;

    @FXML
    private Button convertw;


    @FXML
    private ChoiceBox unit;

    private String[] units={"Mile", "Yard", "Foot"};
    @Override
    public  void initialize(URL arg1, ResourceBundle arg2) {
        unit.getItems().addAll(units);
        unit.setValue("--Select--");
    }

    public void convertonAction(ActionEvent actionEvent) throws Exception {



        ConvertHandler mile_handler = new MILE_Handler();
        ConvertHandler yard_handler = new YARD_Handler();
        ConvertHandler foot_handler = new FOOT_Handler();
        mile_handler.SetSuccessor(yard_handler);
        yard_handler.SetSuccessor(foot_handler);



        mile_handler=new Decimal(mile_handler);
        mile_handler=new Expnotation(mile_handler);
       mile_handler=new UnitName(mile_handler);



        useroutput.setText(String.valueOf(mile_handler.HandleRequest(unit.getValue().toString(),
                Double.parseDouble(userinput.getText()))));

       System.out.println(String.valueOf(mile_handler.HandleRequest(unit.getValue().toString(),
               Double.parseDouble(userinput.getText()))));


    }


}