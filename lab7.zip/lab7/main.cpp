#include<iostream>
#include<cstdlib>
#include <string>
#include <fstream>
using namespace std;



struct sortdListNode{
        char letter;
        int occurences;
        struct sortdListNode *next;
};

struct sortdListNode* fromString(string str)
{
        int arr[26]={0};
        
        struct sortdListNode *head=NULL,*temp=NULL;
        
        for (int x=0;x<str.length();x++)
        {
                if(str[x]>='a'&&str[x]<='z') 
                    arr[str[x]-'a']++;
                if(str[x]>='A'&&str[x]<='Z') 
                    arr[str[x]-'A']++;
             
        }
        
        for(int y=0;y<26;y++)
        {
                if(arr[y]>0)
                {
                        struct sortdListNode* node=(struct sortdListNode*)malloc(sizeof(struct sortdListNode));
                        
                node->letter='A'+(y);
                
                node->occurences=arr[y];
                
                node->next=NULL;
                
                if(head==NULL)
                {
                        head=node;
                        
                        }
                        else
                        {
                                temp->next=node;
                                
                        }
                        temp=node;
                }
        }
        return head;
        
}

void printlist(sortdListNode* check, 	ofstream &outFile)
{
        if(check==NULL)
        {
                cout<<"Empty word\n";
                 outFile<<"Empty word\n";
                return ;
        }
        while(check!=NULL)
        {
                cout<<check->letter<<" "<<check->occurences<<" ";
                outFile<<check->letter<<" "<<check->occurences<<" ";
                check=check->next;
        }
        cout<<endl;
        outFile<<endl;
} 

sortdListNode* combineLists(struct sortdListNode*  list1,struct sortdListNode* list2)
{
        sortdListNode *list3=NULL,*temp=NULL,*previous=NULL;
        
        
        
        if(list1==NULL) 
           return list2;
           
        if(list2==NULL)
          return list1;
          
        list3=list1;
        
        while(list1!=NULL&&list2!=NULL)
        {
                if(list1->letter>list2->letter)
                {
                        temp=list2->next;
                        
                        if(previous==NULL)
                        {
                                list2->next=list1;
                                list3=list2;
                        }
                        else
                        {
                                list2->next=list1;
                                previous->next=list2;
                        
                        }
                        previous=list2;
                        list2=temp;
                }
                else if(list1->letter<list2->letter)
                {
                        previous=list1;
                        
                        list1=list1->next;
                }
                else
                {
                        previous=list1;
                        list1->occurences=list1->occurences+list2->occurences;
                        list1=list1->next;
                        list2=list2->next;
                }
                
                
        }
        return list3;
}



int main()
{
	    
	    
	    	ofstream outFile;
        outFile.open("word.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	    
	    
         sortdListNode *list1=NULL,*list2=NULL,*list3=NULL;
          string word1,word2;
         cout<<"Enter first word: ";
        
         cin>>word1;
         cout<<"Enter second word: ";
         cin>>word2;
         
         list1=fromString(word1);
          cout<<"word 1         ";
 outFile<<"word 1         ";
         printlist(list1,outFile);
        
        list2=fromString(word2);
        cout<<"word 2         ";
         outFile<<"word 2         ";
	printlist(list2,outFile);

         
        list3=combineLists(list1,list2);
        cout<<"combined:         ";
    outFile<<"combined:       ";	
	printlist(list3,outFile);
	

      
	
	

        
        
        
         outFile.close();
       return 0; 
}
