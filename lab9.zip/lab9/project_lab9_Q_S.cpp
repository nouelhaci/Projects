#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;




template<class ItemType>

class Stack

{

    private:

    ItemType arrayStack[5];

    int topOfStack;

    public:

    Stack()

    {

        topOfStack = -1;

    }

    Stack(const Stack<ItemType> &x)

    {

        for(int i = 0; i<=x.topOfStack; i++)
{

            arrayStack[i] = x.arrayStack[i];
}
        topOfStack = x.topOfStack;

    }

    void MakeEmpty()

    {

        topOfStack = -1;

    }

    bool IsEmpty()

    {

        if(topOfStack == -1)

            return true;

        return false;

    }

    bool IsFull()

    {

        if(length() == 5)

            return true;

        return false;

    }

    int length()

    {

        return topOfStack+1;

    }

    void Print(ofstream &outFile)

    {

        for(int i =0 ; i <length(); i++)
{

            cout<<arrayStack[i]<<" ";
outFile<<arrayStack[i]<<" ";}
        cout<<endl;

    }

    bool Push(ItemType x)

    {
    	
    
    	
    	
    	

        if(!IsFull())

            arrayStack[++topOfStack] = x;

    }

    bool Pop(ItemType &x)

    {
    	
    	
    	
    

        if(IsEmpty() )
{

            return false;}

        topOfStack--;

    }

    ItemType Peek(bool &status)

    {

        if(topOfStack > -1)

        {

            status = true;

            return arrayStack[topOfStack];

        }            

        status = false;

      

    }

    ~Stack()

    {

    }

};








template<class ItemType>

struct NodeType

{

    ItemType info;

    NodeType* next;

};

template<class ItemType>

class Queue

{

    private:

    NodeType<ItemType>* front;

    NodeType<ItemType> *rear;

    public:

    Queue()

    {

        front = rear = NULL;

    }

    Queue(const Queue<ItemType> &x)

    {

        NodeType<ItemType>* temp;

        NodeType<ItemType>* t = x.front;

        front = NULL;

        rear = NULL;

        while(t != NULL )

        {

            temp = new NodeType<ItemType>;

            temp->info = t->info;

            temp->next = t->next;

            if(front == NULL)

            {

                front = temp; rear = temp;

            }

            else

            {

                rear->next = temp;

                rear = temp;

            }

            t = t->next;

        }

    }

    void MakeEmpty()

    {
    	
    	
    	
    	
    	
    	front= rear=NULL;


    }

    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {
    /*	int count;

NodeType<ItemType>* s=rear;
        for(NodeType<ItemType>* t = front; t!=s->next; t = t->next)
{

            count++;
}*/

if(length()>=5)
{
	return true;
}
else
{
	return false;
}

        /*NodeType<ItemType>* t = front;

        return front == rear;*/

    }

    int length()

    {

        NodeType<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }

    void Print(ofstream &outFile)

    {
/*NodeType<ItemType>* s=rear;
        for(NodeType<ItemType>* t = front; t!=s->next; t = t->next)
{

            cout<<t->info<<" ";
             outFile<<t->info<<" "<<endl;
        cout<<endl;
}
*/

/* for(NodeType<ItemType>* t = front; t!=rear; t = t->next)
{

            cout<<t->info<<" ";

        cout<<endl;

}*/
NodeType<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";

        cout<<endl;
	t=t->next;
}
    }

    bool Enqueue(ItemType x)

    {

        NodeType<ItemType>* temp;

        temp = new NodeType<ItemType>;

        temp->info = x;

        temp->next = NULL;

        if(front == NULL)

        {

            front = temp; rear = temp;

            return true;

        }

        else if(length() != 5)

        {

            rear->next = temp;

            rear = temp;

            return true;

        }

        else

        {

            return false;

        }

    }

    bool Dequeue(ItemType &x)

    {

        if(IsEmpty())

        {

            return false;

        }
else 
if(front==rear)
{
	free(front);
	front=rear=NULL;
	
	
}
else
{
	NodeType <ItemType>*t = front;

        x = front->info;

        front = front->next;

        delete t;
        return true;
}
        

        

    }

    ItemType FrontPeek(bool &status)

    {

        if(!IsEmpty())

        {
         status = true;
return front->info;
        
            

           // exit(EXIT_FAILURE);

        }
        else
        {
        	status = false;
		}

        

    }

    ~Queue()

    {
     NodeType <ItemType>*f ;
while(front!=NULL)
{
	f=front->next;
	delete front;
	front=f;
}
 delete rear;

        /*delete front;

       

        front = rear = NULL;*/

    }

};







int main()
{
	int value;
	char type, method, action;
		ifstream myFile("readcharQueue.txt");
        
        if(myFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	ofstream outFile;
        outFile.open("writecharQueue.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}


 bool callStatus;
myFile>>type>>method;

	 Stack <int> IntStack;
      int x;



     Stack <float> floatStack;
     float y;
 

	
 
      Stack <char> charStack;
      char z;

	 Queue<int> IntQueue;
  
	
	Queue<float >floatQueue;

	Queue<char >charQueue;

	while (!myFile.eof())
{ 



if(method=='S')
{
//	switch(type)  
if(type=='I') 
{
 
     /* Stack <int> IntStack;
      int x;*/
      
      
      
      myFile>>action;
      	switch(action)  
{case 'R': 
      
      
      if (IntStack.Pop(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl;
	 }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }  
      break; 
case 'P': 

   cout << "The int stack2 contains:  " << endl;
 outFile<<endl<< "The int stack2 contains:  " << endl;
 IntStack.Print(outFile);
 
      break; 
case 'L': 
    cout << "int length  = " << IntStack.length() << endl;
 outFile<< "int length  = " << IntStack.length() << endl;
      break; 
      case 'E': 
    
     if (IntStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack.Peek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     IntStack.MakeEmpty();
	if (IntStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack.Peek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      
      myFile>>value;
      
      if (IntStack.Push(value))
    { cout<<"add"<<value<< " to the stack"<<endl; 
	outFile<<endl<<"add"<<value<<" to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(IntStack.IsFull() == false)
 {
 
    cout << "The int stack is not full !" << endl;
    outFile<< "The int stack is not full !" << endl;}
 else
 {
	 	
    cout << "The int stack is full !" << endl;
    outFile<< "The int stack is full !" << endl;}
      break;
        case 'T': 
        
    IntStack.Peek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< IntStack.Peek(callStatus)<<endl;
	outFile<<"Top element:"<< IntStack.Peek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 
      break;
}
}
      
else if(type=='R') 
{

     /*Stack <float> IntStack;
     float y;*/
     
     
     
     myFile>>action;
      	switch(action)  
{case 'R': 
      
      
      if (floatStack.Pop(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl;
	 }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }  
      break; 
case 'P': 
   
   
   
   cout << "The float stack2 contains:  " << endl;
 outFile<<endl<< "The float stack2 contains:  " << endl;
 floatStack.Print(outFile);
      break; 
case 'L': 
    cout << "float length  = " << floatStack.length() << endl;
 outFile<< "float length  = " << floatStack.length() << endl;
      break; 
      case 'E': 
    
     if (floatStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << floatStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << floatStack.Peek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     floatStack.MakeEmpty();
	if (floatStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << floatStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << floatStack.Peek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      float realvalue;
      myFile>>realvalue;
      
      if (floatStack.Push(realvalue))
    { cout<<"add"<<realvalue<< " to the stack"<<endl; 
	outFile<<endl<<"add"<<realvalue<<" to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(floatStack.IsFull() == false)
 {
 
    cout << "The float stack is not full !" << endl;
    outFile<< "The float stack is not full !" << endl;}
 else
 {
	 	
    cout << "The float stack is full !" << endl;
    outFile<< "The float stack is full !" << endl;}
      break;
        case 'T': 
    floatStack.Peek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< floatStack.Peek(callStatus)<<endl;
	outFile<<"Top element:"<< floatStack.Peek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 
      break;
	
}
     

     
     
     
     
     
     
 }
else if(type=='C') 
{
	
 
      /*Stack <char> IntStack;
      char z;*/
      
      
           myFile>>action;
      	switch(action)  
{case 'R': 
      
      
      if (charStack.Pop(z))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl;
	 }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }  
      break; 
case 'P': 
   
   
   
   cout << "The char stack2 contains:  " << endl;
 outFile<<endl<< "The char stack2 contains:  " << endl;
 charStack.Print(outFile);
      break; 
case 'L': 
    cout << "char length  = " << charStack.length() << endl;
 outFile<< "char length  = " << charStack.length() << endl;
      break; 
      case 'E': 
    
     if (charStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << charStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << charStack.Peek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     charStack.MakeEmpty();
	if (charStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << charStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << charStack.Peek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      char charvalue;
      myFile>>charvalue;
      
      if (charStack.Push(charvalue))
    { cout<<"add"<<charvalue<< " to the stack"<<endl; 
	outFile<<endl<<"add"<<charvalue<<" to the stack"<<endl; }
     else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(charStack.IsFull() == false)
 {
 
    cout << "The char stack is not full !" << endl;
    outFile<< "The char stack is not full !" << endl;}
 else
 {
	 	
    cout << "The char stack is full !" << endl;
    outFile<< "The char stack is full !" << endl;}
      break;
        case 'T': 
    charStack.Peek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< charStack.Peek(callStatus)<<endl;
	outFile<<"Top element:"<< charStack.Peek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 
      break;
	
}
      
      
    
}
	
}
else if(method=='Q')
{
	
//	switch(type)  
if(type=='I')
{
  
     /* Queue<int>IntQueue;
      int x;*/
       myFile>>action;
      	switch(action)  
{case 'R': 
      
      
     if (IntQueue.Dequeue(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
      break; 
case 'P': 
   cout << "The int Queue contains:  " << endl;
 outFile<<endl<< "The int Queue contains:  " << endl;
 IntQueue.Print(outFile);

      break; 
case 'L': 
   cout << "int length 1 = " << IntQueue.length() << endl;
 outFile<< "int length 1 = " << IntQueue.length() << endl;
      break; 
      case 'E': 
    
     if (IntQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     IntQueue.MakeEmpty();
      if (IntQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      
      myFile>>value;
      
      if  (IntQueue.Enqueue(value))
    { cout<<"add"<<value<<" to the Queue"<<endl;
	outFile<<"add "<<value<<" to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(IntQueue.IsFull() == false)
 {
 
    cout << "The int queue is not full !"<< endl;
    outFile<< "The int queue is not full !"<< endl;
    
}
 else
 {
 
    cout << "The int queue is full !" << endl;
    outFile<< "The int queue is full !" << endl;
}
      break;
    case 'T': 
    bool callStatus;
   IntQueue.FrontPeek(callStatus);

 if (callStatus)
    {cout<<"Top element:"<< IntQueue.FrontPeek(callStatus)<<endl;
	outFile<<"Top element:"<< IntQueue.FrontPeek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 

      break;
	
}
      
      
}
     
else if(type=='R') 
{
  
   /* Queue<float>floatQueue;
    float y;*/
      myFile>>action;
      	switch(action)  
{case 'R': 
      
      
     if (floatQueue.Dequeue(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
      break; 
case 'P': 
   
   
   
   cout << "The float Queue contains:  " << endl;
 outFile<<endl<< "The float Queue contains:  " << endl;
 floatQueue.Print(outFile);
      break; 
case 'L': 
   cout << "float length 1 = " << floatQueue.length() << endl;
 outFile<< "float length 1 = " << floatQueue.length() << endl;
      break; 
      case 'E': 
    
     if (floatQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << floatQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << floatQueue.FrontPeek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     floatQueue.MakeEmpty();
      if (floatQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << floatQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << floatQueue.FrontPeek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      float realvalue;
      myFile>>realvalue;
      
      if  (floatQueue.Enqueue(realvalue))
    { cout<<"add"<<realvalue<<" to the Queue"<<endl;
	outFile<<"add "<<realvalue<<" to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(floatQueue.IsFull() == false)
 {
 
    cout << "The float queue is not full !"<< endl;
    outFile<< "The float queue is not full !"<< endl;
    
}
 else
 {
 
    cout << "The float queue is full !" << endl;
    outFile<< "The float queue is full !" << endl;
}
      break;
        case 'T': 
    floatQueue.FrontPeek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< floatQueue.FrontPeek(callStatus)<<endl;
	outFile<<"Top element:"<< floatQueue.FrontPeek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 
      break;
	
}
    
}
    
else if(type=='C') 
{

     /* Queue<char>charQueue;
      char z;*/
            myFile>>action;
      	switch(action)  
{case 'R': 
      
      
     if (charQueue.Dequeue(z))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
      break; 
case 'P': 
   
   
   
   cout << "The char Queue contains:  " << endl;
 outFile<<endl<< "The char Queue contains:  " << endl;
 charQueue.Print(outFile);
      break; 
case 'L': 
   cout << "float length  = " << charQueue.length() << endl;
 outFile<< "float length  = " << charQueue.length() << endl;
      break; 
      case 'E': 
    
     if (charQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << charQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << charQueue.FrontPeek(callStatus) << endl; 
  } 
      break; 
      case 'M': 
     
     charQueue.MakeEmpty();
      if (charQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << charQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << charQueue.FrontPeek(callStatus) << endl; 
  } 
     
     
      break; 
      case 'A': 
      char charvalue;
      myFile>>charvalue;
      
      if  (charQueue.Enqueue(charvalue))
    { cout<<"add"<<charvalue<<" to the Queue"<<endl;
	outFile<<"add "<<charvalue<<" to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
      break; 
      case 'F': 
     if(charQueue.IsFull() == false)
 {
 
    cout << "The char queue is not full !"<< endl;
    outFile<< "The char queue is not full !"<< endl;
    
}
 else
 {
 
    cout << "The char queue is full !" << endl;
    outFile<< "The char queue is full !" << endl;
}
      break;
        case 'T': 
    charQueue.FrontPeek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< charQueue.FrontPeek(callStatus)<<endl;
	outFile<<"Top element:"<< charQueue.FrontPeek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; } 
      break;
	
}
      
      
   
	
	
}







}

	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	outFile.close();
	myFile.close();
	return 0;
}
