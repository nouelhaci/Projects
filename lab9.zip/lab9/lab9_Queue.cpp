#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;



template<class ItemType>

struct NodeType

{

    ItemType info;

    NodeType* next;

};

template<class ItemType>

class Queue

{

    private:

    NodeType<ItemType>* front;

    NodeType<ItemType> *rear;

    public:

    Queue()

    {

        front = rear = NULL;

    }

    Queue(const Queue<ItemType> &x)

    {

        NodeType<ItemType>* temp;

        NodeType<ItemType>* t = x.front;

        front = NULL;

        rear = NULL;

        while(t != NULL )

        {

            temp = new NodeType<ItemType>;

            temp->info = t->info;

            temp->next = t->next;

            if(front == NULL)

            {

                front = temp; rear = temp;

            }

            else

            {

                rear->next = temp;

                rear = temp;

            }

            t = t->next;

        }

    }

    void MakeEmpty()

    {
    	
    	
    	
    	
    	
    	front= rear=NULL;


    }

    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {
    /*	int count;

NodeType<ItemType>* s=rear;
        for(NodeType<ItemType>* t = front; t!=s->next; t = t->next)
{

            count++;
}*/

if(length()>=5)
{
	return true;
}
else
{
	return false;
}

        /*NodeType<ItemType>* t = front;

        return front == rear;*/

    }

    int length()

    {

        NodeType<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }

    void Print(ofstream &outFile)

    {
/*NodeType<ItemType>* s=rear;
        for(NodeType<ItemType>* t = front; t!=s->next; t = t->next)
{

            cout<<t->info<<" ";
             outFile<<t->info<<" "<<endl;
        cout<<endl;
}
*/

/* for(NodeType<ItemType>* t = front; t!=rear; t = t->next)
{

            cout<<t->info<<" ";

        cout<<endl;

}*/
NodeType<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";

        cout<<endl;
	t=t->next;
}
    }

    bool Enqueue(ItemType x)

    {

        NodeType<ItemType>* temp;

        temp = new NodeType<ItemType>;

        temp->info = x;

        temp->next = NULL;

        if(front == NULL)

        {

            front = temp; rear = temp;

            return true;

        }

        else if(length() != 5)

        {

            rear->next = temp;

            rear = temp;

            return true;

        }

        else

        {

            return false;

        }

    }

    bool Dequeue(ItemType &x)

    {

        if(IsEmpty())

        {

            return false;

        }
else 
if(front==rear)
{
	free(front);
	front=rear=NULL;
	
	
}
else
{
	NodeType <ItemType>*t = front;

        x = front->info;

        front = front->next;

        delete t;
        return true;
}
        

        

    }

    ItemType FrontPeek(bool &status)

    {

        if(!IsEmpty())

        {
         status = true;
return front->info;
        
            

           // exit(EXIT_FAILURE);

        }
        else
        {
        	status = false;
		}

    }

    ~Queue()

    {
     NodeType <ItemType>*f ;
while(front!=NULL)
{
	f=front->next;
	delete front;
	front=f;
}
 delete rear;

        /*delete front;

       

        front = rear = NULL;*/

    }

};






int main()
{
	
		ofstream outFile;
        outFile.open("QueueInt.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	
	
	Queue<int>IntQueue;
 int x;
 bool callStatus;
 IntQueue.MakeEmpty();
 if (IntQueue.Dequeue(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 if  (IntQueue.Enqueue(10))
    { cout<<"add 10 to the Queue"<<endl;
	outFile<<"add 10 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (IntQueue.Enqueue(20))
    { cout<<"add 20 to the Queue"<<endl;
	outFile<<"add 20 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl;  }
 if  (IntQueue.Enqueue(30))
    { cout<<"add 30 to the Queue"<<endl;
	outFile<<"add 30 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (IntQueue.Enqueue(40))
    { cout<<"add 40 to the Queue"<<endl;
	outFile<<"add 40 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 cout << "int length 3 = " << IntQueue.length() << endl;
 if (IntQueue.Dequeue(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 cout << "int length 4 = " << IntQueue.length() << endl;
 outFile<< "int length 4 = " << IntQueue.length() << endl;
 cout << "The int queue contains:  " << endl;
 outFile<< "The int queue contains:  " << endl;
 IntQueue.Print(outFile);
 if(IntQueue.IsFull() == false)
 {
 
    cout << "The int queue is not full !"<< endl;
    outFile<< "The int queue is not full !"<< endl;
    
}
 else
 {
 
    cout << "The int queue is full !" << endl;
    outFile<< "The int queue is full !" << endl;
}
	
IntQueue.MakeEmpty();




if (IntQueue.Dequeue(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
	
	
	if (IntQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
  } 
 cout << "int length 1 = " << IntQueue.length() << endl;
 outFile<< "int length 1 = " << IntQueue.length() << endl;
 cout << "The int Queue contains:  " << endl;
 outFile<<endl<< "The int Queue contains:  " << endl;
 IntQueue.Print(outFile);

	
	
	
	if  (IntQueue.Enqueue(1))
    { cout<<"add 1 to the Queue"<<endl;
	outFile<<"add 1 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (IntQueue.Enqueue(2))
    { cout<<"add 2 to the Queue"<<endl;
	outFile<<"add 2 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl;  }
 if  (IntQueue.Enqueue(3))
    { cout<<"add 3 to the Queue"<<endl;
	outFile<<"add 3 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (IntQueue.Enqueue(4))
    { cout<<"add 4 to the Queue"<<endl;
	outFile<<"add 4 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
	
	if  (IntQueue.Enqueue(5))
    { cout<<"add 5 to the Queue"<<endl;
	outFile<<"add 5 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
	
	
	
	 if (IntQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
  } 
	if(IntQueue.IsFull() == false)
 {
 
    cout << "The int Queue is not full !" << endl;
    outFile<< "The int Queue is not full !" << endl;}
 else
 {
	 	
    cout << "The int Queue is full !" << endl;
    outFile<< "The int Queue is full !" << endl;}
	
	cout << "int length 2 = " << IntQueue.length() << endl;
 outFile<< "int length 2 = " << IntQueue.length() << endl;
	
	cout << "The int Queue contains:  " << endl;
 outFile<<endl<< "The int Queue contains:  " << endl;
 IntQueue.Print(outFile);
	
	
	
	IntQueue.MakeEmpty();
	if (IntQueue.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << IntQueue.FrontPeek(callStatus) << endl; 
  } 
		cout << "int length 2 = " << IntQueue.length() << endl;
 outFile<< "int length 2 = " << IntQueue.length() << endl;
	
	cout << "The int Queue contains:  " << endl;
 outFile<<endl<< "The int Queue contains:  " << endl;
 IntQueue.Print(outFile);

	
	
	
	
	
	
	outFile.close();
	
	
	
	
	
	
	
	
	
	
	outFile.open("QueueFloat.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
Queue<float>FloatQueue;
 float y;
 FloatQueue.MakeEmpty();
 if (FloatQueue.Dequeue(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 if (FloatQueue.Enqueue(7.1))
    { cout<<"add 7.1 to the Queue"<<endl;
	outFile<<"add 7.1 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 cout << "float length 3 = " << FloatQueue.length() << endl;
 if (FloatQueue.Dequeue(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 cout << "float length 3 = " << FloatQueue.length() << endl;
 if (FloatQueue.Enqueue(2.3))

    { cout<<"add 2.3 to the Queue"<<endl;
	outFile<<"add 2.3 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (FloatQueue.Enqueue(2.3))
    { cout<<"add 2.3 to the Queue"<<endl;
	outFile<<"add 2.3 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 cout << "float length 4 = " << FloatQueue.length() << endl;
 if (FloatQueue.Enqueue(3.1))
    { cout<<"add 3.1 to the Queue"<<endl;
	outFile<<"add 3.1 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (FloatQueue.Dequeue(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    {cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 cout << "The float queue contains: "  << endl;
 outFile<< "The float queue contains: "  << endl;
 FloatQueue.Print(outFile);
 Queue<float> FloatQueue2 = FloatQueue;
 cout << "The float queue 2 contains:"   << endl;
 outFile<< "The float queue 2 contains:"   << endl;
 FloatQueue2.Print(outFile);
 //FloatQueue2.MakeEmpty();
 
FloatQueue2.MakeEmpty();
 
 cout << "The float queue 3 contains:  " << endl;
 outFile<< "The float queue 3 contains:  " << endl;
 FloatQueue2.Print(outFile);
	
	
	
	
	
	
	
	FloatQueue2.MakeEmpty();




if (FloatQueue2.Dequeue(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
	
	
	if (FloatQueue2.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
  } 
 cout << "int length 1 = " << FloatQueue2.length() << endl;
 outFile<< "int length 1 = " << FloatQueue2.length() << endl;
 cout << "The float Queue contains:  " << endl;
 outFile<<endl<< "The float Queue contains:  " << endl;
 FloatQueue2.Print(outFile);

	
	
	
	if  (FloatQueue2.Enqueue(1.1))
    { cout<<"add 1.1 to the Queue"<<endl;
	outFile<<"add 1.1 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (FloatQueue2.Enqueue(2.2))
    { cout<<"add 2.2 to the Queue"<<endl;
	outFile<<"add 2.2 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl;  }
 if  (FloatQueue2.Enqueue(3.3))
    { cout<<"add 3.3 to the Queue"<<endl;
	outFile<<"add 3.3 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if  (FloatQueue2.Enqueue(4.4))
    { cout<<"add 4.4 to the Queue"<<endl;
	outFile<<"add 4.4 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
	
	if  (FloatQueue2.Enqueue(5.5))
    { cout<<"add 5.5 to the Queue"<<endl;
	outFile<<"add 5.5 to the Queue"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
	
	cout << "The float Queue contains:  " << endl;
 outFile<<endl<< "The float Queue contains:  " << endl;
 FloatQueue2.Print(outFile);
	
	 if (FloatQueue2.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
  } 
	if(FloatQueue2.IsFull() == false)
 {
 
    cout << "The float Queue is not full !" << endl;
    outFile<< "The float Queue is not full !" << endl;}
 else
 {
	 	
    cout << "The float Queue is full !" << endl;
    outFile<< "The float Queue is full !" << endl;}
	
	cout << "float length 2 = " << FloatQueue2.length() << endl;
 outFile<< "float length 2 = " << FloatQueue2.length() << endl;
	
	cout << "The float Queue contains:  " << endl;
 outFile<<endl<< "The float Queue contains:  " << endl;
 FloatQueue2.Print(outFile);
	
	
	
	FloatQueue2.MakeEmpty();
	cout<<"make empty"<<endl;
	if (FloatQueue2.IsEmpty())
  { cout<<"the Queue is empty"<<endl;
  outFile<<"the Queue is empty"<<endl; }
 else  
  {
  	cout<<"the Queue is not empty"<<endl;
  	outFile<<"the Queue is not empty"<<endl;
   cout << "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
   outFile<< "top element = " << FloatQueue2.FrontPeek(callStatus) << endl; 
  } 
		cout << "float length 2 = " << FloatQueue2.length() << endl;
 outFile<< "float length 2 = " << FloatQueue2.length() << endl;
	
	cout << "The float Queue contains:  " << endl;
 outFile<<endl<< "The float Queue contains:  " << endl;
 FloatQueue2.Print(outFile);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	outFile.close();
	return 0;
}
