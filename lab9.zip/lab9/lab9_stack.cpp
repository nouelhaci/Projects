#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;




template<class ItemType>

class Stack

{

    private:

    ItemType arrayStack[5];

    int topOfStack;

    public:

    Stack()

    {

        topOfStack = -1;

    }

    Stack(const Stack<ItemType> &x)

    {

        for(int i = 0; i<=x.topOfStack; i++)
{

            arrayStack[i] = x.arrayStack[i];
}
        topOfStack = x.topOfStack;

    }

    void MakeEmpty()

    {

        topOfStack = -1;

    }

    bool IsEmpty()

    {

        if(topOfStack == -1)

            return true;

        return false;

    }

    bool IsFull()

    {

        if(length() == 5)

            return true;

        return false;

    }

    int length()

    {

        return topOfStack+1;

    }

    void Print(ofstream &outFile)

    {

        for(int i =0 ; i <length(); i++)
{

            cout<<arrayStack[i]<<" ";
outFile<<arrayStack[i]<<" ";}
        cout<<endl;

    }

    bool Push(ItemType x)

    {
    	
    
    	
    	
    	

        if(!IsFull())

            arrayStack[++topOfStack] = x;

    }

    bool Pop(ItemType &x)

    {
    	
    	
    	
    

        if(IsEmpty() )
{

            return false;}

        topOfStack--;

    }

    ItemType Peek(bool &status)

    {

        if(topOfStack > -1)

        {

            status = true;

            return arrayStack[topOfStack];

        }            

        status = false;

      

    }

    ~Stack()

    {

    }

};

int main()
{
	
		ofstream outFile;
        outFile.open("StackInt.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	
	
	
	
	Stack <int> IntStack;
int x;
bool callStatus;
 if (IntStack.Pop(x))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl;
	 }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }      
  
 IntStack.Peek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< IntStack.Peek(callStatus)<<endl;
	outFile<<"Top element:"<< IntStack.Peek(callStatus)<<endl;}
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; }     
 if (IntStack.Push(11))
    { cout<<"add 11 to the stack"<<endl;
	outFile<<"add 11 to the stack"<<endl;}
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }       
 if (IntStack.Push(22))
    { cout<<"add 22 to the stack"<<endl;
	outFile<<"add 22 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }       
 cout << "int length 1 = " << IntStack.length() << endl;
 outFile<< "int length 1 = " << IntStack.length() << endl;
 if (IntStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack.Peek(callStatus) << endl; 
  } 
 if (IntStack.Pop(x))
    { cout<<"Item removed"<<endl;
	outFile<<"Item removed"<<endl;}
 else
    { cout<<"Could not remove item"<<endl; 
	outFile<<"Could not remove item"<<endl; }       
 if (IntStack.Push(33))
    {  cout<<"add 33 to the stack"<<endl;
	outFile<<"add 33 to the stack"<<endl; }
 else
    {  cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }       
 cout << "int length 2 = " << IntStack.length() << endl;
 outFile<< "int length 2 = " << IntStack.length() << endl;
 cout << "The int stack contains:  " << endl;
 outFile<< "The int stack contains:  " << endl;
 IntStack.Print(outFile);
 if (IntStack.Push(44))
    { cout<<"add 44 to the stack"<<endl; 
	outFile<<endl<<"add 44 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (IntStack.Push(55))
    { cout<<"add 55 to the stack"<<endl;
	outFile<<"add 55 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (IntStack.Push(66))
    { cout<<"add 66 to the stack"<<endl; 
	outFile<<"add 66 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }

 if(IntStack.IsFull() == false)
 {
 
    cout << "The int stack is not full !" << endl;
    outFile<< "The int stack is not full !" << endl;}
 else
 {
	 	
    cout << "The int stack is full !" << endl;
    outFile<< "The int stack is full !" << endl;}
 Stack <int> IntStack2(IntStack);
 cout << "The int stack2 contains:  " << endl;
 outFile<< "The int stack2 contains:  " << endl;
 IntStack2.Print(outFile);
 IntStack2.MakeEmpty();
 cout << "The int stack2 contains:  " << endl;
 outFile<<endl<< "The int stack2 contains:  " << endl;
 IntStack2.Print(outFile);
 
 
 if (IntStack2.Pop(x))
    { cout<<"Item removed"<<endl;
	outFile<<"Item removed"<<endl;}
 else
    { cout<<"Could not remove item"<<endl; 
	outFile<<"Could not remove item"<<endl; } 
	
 if (IntStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack2.Peek(callStatus) << endl; 
  } 
 cout << "int length 1 = " << IntStack2.length() << endl;
 outFile<< "int length 1 = " << IntStack2.length() << endl;
 cout << "The int stack2 contains:  " << endl;
 outFile<<endl<< "The int stack2 contains:  " << endl;
 IntStack2.Print(outFile);
 if (IntStack2.Push(1))
    { cout<<"add 1 to the stack"<<endl; 
	outFile<<endl<<"add 1 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (IntStack2.Push(2))
    { cout<<"add 2 to the stack"<<endl;
	outFile<<"add 2 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (IntStack2.Push(3))
    { cout<<"add 3 to the stack"<<endl; 
	outFile<<"add 3 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 if (IntStack2.Push(4))
    { cout<<"add 4 to the stack"<<endl; 
	outFile<<"add 4 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
	if (IntStack2.Push(5))
    { cout<<"add 5 to the stack"<<endl; 
	outFile<<"add 5 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 if (IntStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack2.Peek(callStatus) << endl; 
  } 
	if(IntStack2.IsFull() == false)
 {
 
    cout << "The int stack is not full !" << endl;
    outFile<< "The int stack is not full !" << endl;}
 else
 {
	 	
    cout << "The int stack is full !" << endl;
    outFile<< "The int stack is full !" << endl;}
	
	cout << "int length 2 = " << IntStack2.length() << endl;
 outFile<< "int length 2 = " << IntStack2.length() << endl;
	
	cout << "The int stack2 contains:  " << endl;
 outFile<<endl<< "The int stack2 contains:  " << endl;
 IntStack2.Print(outFile);
 
	IntStack2.MakeEmpty();
	if (IntStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack2.Peek(callStatus) << endl; 
  } 
		cout << "int length 2 = " << IntStack2.length() << endl;
 outFile<< "int length 2 = " << IntStack2.length() << endl;
	
	cout << "The int stack2 contains:  " << endl;
 outFile<<endl<< "The int stack2 contains:  " << endl;
 IntStack2.Print(outFile);
	outFile.close();
	
	
	
	
	
	outFile.open("StackFloat.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	Stack <float> FloatStack;
 float y;
 if (FloatStack.Pop(y))
    { cout<<"Item removed"<<endl;
    outFile<<"Item removed"<<endl; }
 else
    { cout<<"Could not remove item"<<endl;
	outFile<<"Could not remove item"<<endl; }
 FloatStack.Peek(callStatus);
 if (callStatus)
    {cout<<"Top element:"<< IntStack.Peek(callStatus)<<endl;
	outFile<<"Top element:"<< IntStack.Peek(callStatus)<<endl; }
 else
    { cout<<"could not return top element"<<endl;
	outFile<<"could not return top element"<<endl; }
 if (FloatStack.Push(7.1))
    { cout<<"add 7.1 to the stack"<<endl;
	outFile<<"add 7.1 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 cout << "float length 1 = " << FloatStack.length() << endl;
 outFile<< "float length 1 = " << FloatStack.length() << endl;
 if (FloatStack.Push(2.3))
    { cout<<"add 2.1 to the stack"<<endl;
	outFile<<"add 2.1 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 if (FloatStack.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
   cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << IntStack.Peek(callStatus) << endl; 
   outFile<< "top element = " << IntStack.Peek(callStatus) << endl;
  } 
 if (FloatStack.Push(3.1))
    { cout<<"add 3.1 to the stack"<<endl;
	outFile<<"add 3.1 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 cout << "float length 2 = " << FloatStack.length() << endl;
 FloatStack.Pop(y);
 cout << "The float stack contains:  " << endl;
 outFile << "The float stack contains:  " << endl;
 FloatStack.Print(outFile);
 Stack <float> FloatStack2 = FloatStack;
 cout << "The float stack 2 contains:  " << endl;
 outFile<< "The float stack 2 contains:  " << endl;
 FloatStack2.Print(outFile);
 FloatStack.MakeEmpty();
 cout << "The float stack 3 contains:  " << endl;
 outFile<< "The float stack 3 contains:  " << endl;
 FloatStack2.Print(outFile);
	
	
	
	
	
	
	 if (FloatStack2.Pop(y))
    { cout<<"Item removed"<<endl;
	outFile<<"Item removed"<<endl;}
 else
    { cout<<"Could not remove item"<<endl; 
	outFile<<"Could not remove item"<<endl; } 
	
 if (FloatStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << FloatStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << FloatStack2.Peek(callStatus) << endl; 
  } 
 cout << "int length 1 = " << FloatStack2.length() << endl;
 outFile<< "int length 1 = " << FloatStack2.length() << endl;
 cout << "The float stack2 contains:  " << endl;
 outFile<<endl<< "The float stack2 contains:  " << endl;
 FloatStack2.Print(outFile);
 if (FloatStack2.Push(1.1))
    { cout<<"add 1.1 to the stack"<<endl; 
	outFile<<endl<<"add 1.1 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (FloatStack2.Push(2.2))
    { cout<<"add 2.2 to the stack"<<endl;
	outFile<<"add 2.2 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl;
	outFile<<"adding an element failed"<<endl; }
 if (FloatStack2.Push(3.3))
    { cout<<"add 3.3 to the stack"<<endl; 
	outFile<<"add 3.3 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 if (FloatStack2.Push(4.4))
    { cout<<"add 4.4 to the stack"<<endl; 
	outFile<<"add 4.4 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
	if (FloatStack2.Push(5.5))
    { cout<<"add 5.5 to the stack"<<endl; 
	outFile<<"add 5.5 to the stack"<<endl; }
 else
    { cout<<"adding an element failed"<<endl; 
	outFile<<"adding an element failed"<<endl; }
 if (FloatStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << FloatStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << FloatStack2.Peek(callStatus) << endl; 
  } 
	if(FloatStack2.IsFull() == false)
 {
 
    cout << "The float stack is not full !" << endl;
    outFile<< "The float stack is not full !" << endl;}
 else
 {
	 	
    cout << "The int stack is full !" << endl;
    outFile<< "The int stack is full !" << endl;}
	
	cout << "float length 2 = " << FloatStack2.length() << endl;
 outFile<< "float length 2 = " << FloatStack2.length() << endl;
	
	cout << "The float stack2 contains:  " << endl;
 outFile<<endl<< "The float stack2 contains:  " << endl;
 FloatStack2.Print(outFile);
 
	FloatStack2.MakeEmpty();
	if (FloatStack2.IsEmpty())
  { cout<<"the stack is empty"<<endl;
  outFile<<"the stack is empty"<<endl; }
 else  
  {
  	cout<<"the stack is not empty"<<endl;
  	outFile<<"the stack is not empty"<<endl;
   cout << "top element = " << FloatStack2.Peek(callStatus) << endl; 
   outFile<< "top element = " << FloatStack2.Peek(callStatus) << endl; 
  } 
		cout << "float length 2 = " << FloatStack2.length() << endl;
 outFile<< "float length 2 = " << FloatStack2.length() << endl;
	
	cout << "The float stack2 contains:  " << endl;
 outFile<<endl<< "The float stack2 contains:  " << endl;
 FloatStack2.Print(outFile);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	outFile.close();
	return 0;
}


