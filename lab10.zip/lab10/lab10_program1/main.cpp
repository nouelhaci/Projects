#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;
template<class ItemType>
struct node

{

    ItemType info;

    node* next;

};

template<class ItemType>

class Stackone

{

    private:
    ItemType arrayStack[5];

    int topOfStack;

    public:

    Stackone()

    {

        topOfStack = -1;

    }

    Stackone(const Stackone<ItemType> &x)

    {

        for(int i = 0; i<=x.topOfStack; i++)
{

            arrayStack[i] = x.arrayStack[i];
}
        topOfStack = x.topOfStack;

    }

    void MakeEmpty()

    {

        topOfStack = -1;

    }

    bool IsEmpty()

    {

        if(topOfStack == -1)

            return true;

        return false;

    }

    bool IsFull()

    {

        if(length() == 5)

            return true;

        return false;

    }

    int length()

    {

        return topOfStack+1;

    }

    void Print(/*ofstream &outFile*/)

    {

        for(int i =0 ; i <length(); i++)
{

            cout<<arrayStack[i]<<" ";
//outFile<<arrayStack[i]<<" ";}
        cout<<endl;

    }
}

    bool Push(ItemType x)

    {
    	
    
    	
    	
    	

        if(!IsFull())
{

            arrayStack[++topOfStack] = x;
        return true;
		}

    }


    bool Pop(ItemType &x)

    {
    	

        if(IsEmpty() )
{

            return false;}

        topOfStack--;

    }

    ItemType Peek(bool &status)

    {

        if(topOfStack > -1)

        {

            status = true;

            return arrayStack[topOfStack];

        }            

        status = false;

      

    }

    ~Stackone()

    {

    }
























};



/*template<class ItemType>

class Stacktwo

{

    private:

    NodeType<ItemType>* front;

    NodeType<ItemType> *rear;

    public:

    Stacktwo()

    {

        front = rear = NULL;

    }

    Stacktwo(const Stacktwo<ItemType> &x)

    {

        NodeType<ItemType>* temp;

        NodeType<ItemType>* t = x.front;

        front = NULL;

        rear = NULL;

        while(t != NULL )

        {

            temp = new NodeType<ItemType>;

            temp->info = t->info;

            temp->next = t->next;

            if(front == NULL)

            {

                front = temp; rear = temp;

            }

            else

            {

                rear->next = temp;

                rear = temp;

            }

            t = t->next;

        }

    }

    void MakeEmpty()

    {
    	
    	
    	
    	
    	
    	front= rear=NULL;


    }

    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {

if(length()>=5)
{
	return true;
}
else
{
	return false;
}

        /*NodeType<ItemType>* t = front;

        return front == rear;

    }

    int length()

    {

        NodeType<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }

    void Print(/*ofstream &outFile)

    {

NodeType<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";

        cout<<endl;
	t=t->next;
}
    }

    bool push(ItemType x)

    {

        NodeType<ItemType>* temp;

        temp = new NodeType<ItemType>;

        temp->info = x;

        temp->next = NULL;

        if(front == NULL)

        {

            front = temp; //rear = temp;

            return true;

        }

        else if(length() != 5)

        {

            rear->next = temp;

            rear = temp;

            return true;

        }

        else

        {

            return false;

        }

    }

    bool pop(ItemType &x)

    {

        if(IsEmpty())

        {

            return false;

        }
else 
if(front==rear)
{
	free(front);
	front=rear=NULL;
	
	
}
else
{
	NodeType <ItemType>*t = front;

        x = front->info;

        front = front->next;

        delete t;
        return true;
}
        

        

    }

    ItemType Peek(bool &status)

    {

        if(!IsEmpty())

        {
         status = true;
return front->info;
        
            

           // exit(EXIT_FAILURE);

        }
        else
        {
        	status = false;
		}

    }

    ~Stacktwo()

    {
     NodeType <ItemType>*f ;
while(front!=NULL)
{
	f=front->next;
	delete front;
	front=f;
}
 delete rear;

        /*delete front;

       

        front = rear = NULL;

    }

};*/





template<class ItemType>

class Stacktwo

{

    private:

    node<ItemType>* front;



    public:

  


Stacktwo()
	{
		front = NULL;
	}
	// push method to add data element
	void push(ItemType x)
{
	// creating a new node
	node <ItemType>*temp;
	temp = new node<ItemType>();
	// setting data to it
	temp->info = x;

	// add the node in front of list
	if(front == NULL)
	{
		temp->next = NULL;
	}
	else
	{
		temp->next = front;
	}
	front = temp;
}

	
	
	
	void Print(ofstream &outFile)

    {

node<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";
outFile<<t->info<<" ";
        //cout<<endl;
	t=t->next;
}
    }
    
    
    
        int length()

    {

        node<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }
    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {

if(length()>=5)
{
	return true;
}
else
{
	return false;
}
}
ItemType top()
{
	return front->info;
}
void pop()
{
	// if empty
	if(front == NULL)
		cout << "UNDERFLOW\n";
	
	// delete the first element
	else
	{
		node <ItemType>*temp = front;
		front = front->next;
		delete(temp);
	}
}
};

























template<typename T>
void minMaxFunc(T data[] , int size,ofstream &output  )
{
	

	T y;
	 bool callStatus;
	Stackone <T> arrstack;
	Stacktwo <T> liststack;

  

	for(int x=0; x<size;x++)
	{//arrstack.MakeEmpty();
		cout<<endl<<"check num:"<<x<< " ";
		 output<<endl<<"check num:"<<x<< " ";
		cout<<"the list:";
		output<<"the list:";
		liststack.Print(output);
		cout<<endl;
		output<<endl;
		cout<<"check data :"<<data[x]<< " ";
		output<<"check data :"<<data[x]<< " ";
		if(!liststack.IsFull())
{
	

		while(!liststack.IsEmpty() && liststack.top()<data[x])
		{
		cout<<endl<<"peek"<<liststack.top()<<"<"<<data[x];
		output<<endl<<"peek"<<liststack.top()<<"<"<<data[x];
		
		
				arrstack.Push(liststack.top());
				liststack.pop();
	
		
		}
	
			liststack.push(data[x]);

		while(!arrstack.IsEmpty())
		{
			
			liststack.push(arrstack.Peek(callStatus));
				arrstack.Pop(y);
		
		}
	}
else
{
	cout<<endl<<"Too many input values. The only first 5 values have been processed "<<endl;
	output<<endl<<"Too many input values. The only first 5 values have been processed "<<endl;
}
		
	}
	cout<<endl;
	output<<endl;
cout<<"Sorted list:"<<endl;
output<<"Sorted list:"<<endl;
	liststack.Print(output);
cout<<endl<<"The minimum value is: "<<liststack.top();
	output<<endl<<"The minimum value is: "<<liststack.top();
	
	
 } 







bool is_empty(ifstream& pFile)
{
    return pFile.peek() == std::ifstream::traits_type::eof();
}





int main()
{
	int numbers[5], size=5;
	int x=0;
	
	
	ofstream output;
        output.open("writeintdata.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}

	
	
	
	
	
	
	 ifstream intFile("intdata.txt");
       if(intFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
		if (is_empty(intFile))
{
    cout<<"file is empty"<<endl;
}
	while (!intFile.eof())
{


intFile>>numbers[x];
x++;

  
}
	
	minMaxFunc(numbers,size,output);
	intFile.close();
	output.close();
	
	
	
	
	cout<<endl<<endl<<endl;
	float realnumbers[5];
	 x=0;
	 size=5;
	 
	 
	 output.open("writefloatdata.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}

	 
	 ifstream realFile("realnumdata.txt");
       if(realFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
			if (is_empty(realFile))
{
    cout<<"file is empty"<<endl;
}
	while (!realFile.eof())
{


realFile>>realnumbers[x];
x++;

  
}
	
	minMaxFunc(realnumbers,size,output);
	realFile.close();
	output.close();
	
	
	
	
	
	
	
	
	cout<<endl<<endl<<endl;
	char letter[6];
	 x=0;
	 size=6;
	 
	 
	 
	 output.open("writeletterdata.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	 
	 
	 ifstream letterFile("lettersdata.txt");
       if(letterFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
				if (is_empty(letterFile))
{
    cout<<"file is empty"<<endl;
}
	while (!letterFile.eof())
{


letterFile>>letter[x];
x++;

  
}
	
	minMaxFunc(letter,size,output);
	letterFile.close();
	output.close();
	return 0;
}
