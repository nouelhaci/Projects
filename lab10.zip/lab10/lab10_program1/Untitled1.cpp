#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;
template<class ItemType>
struct node

{

    ItemType info;

    node* next;

};

template<class ItemType>

class Stackone

{

    private:
    ItemType arrayStack[5];

    int topOfStack;

    public:

    Stackone()

    {

        topOfStack = -1;

    }

    Stackone(const Stackone<ItemType> &x)

    {

        for(int i = 0; i<=x.topOfStack; i++)
{

            arrayStack[i] = x.arrayStack[i];
}
        topOfStack = x.topOfStack;

    }

    void MakeEmpty()

    {

        topOfStack = -1;

    }

    bool IsEmpty()

    {

        if(topOfStack == -1)

            return true;

        return false;

    }

    bool IsFull()

    {

        if(length() == 5)

            return true;

        return false;

    }

    int length()

    {

        return topOfStack+1;

    }

    void Print(/*ofstream &outFile*/)

    {

        for(int i =0 ; i <length(); i++)
{

            cout<<arrayStack[i]<<" ";
//outFile<<arrayStack[i]<<" ";}
        cout<<endl;

    }
}

    bool Push(ItemType x)

    {
    	
    
    	
    	
    	

        if(!IsFull())
{

            arrayStack[++topOfStack] = x;
        return true;
		}

    }


    bool Pop(ItemType &x)

    {
    	

        if(IsEmpty() )
{

            return false;}

        topOfStack--;

    }

    ItemType Peek(bool &status)

    {

        if(topOfStack > -1)

        {

            status = true;

            return arrayStack[topOfStack];

        }            

        status = false;

      

    }

    ~Stackone()

    {

    }
























};



/*template<class ItemType>

class Stacktwo

{

    private:

    NodeType<ItemType>* front;

    NodeType<ItemType> *rear;

    public:

    Stacktwo()

    {

        front = rear = NULL;

    }

    Stacktwo(const Stacktwo<ItemType> &x)

    {

        NodeType<ItemType>* temp;

        NodeType<ItemType>* t = x.front;

        front = NULL;

        rear = NULL;

        while(t != NULL )

        {

            temp = new NodeType<ItemType>;

            temp->info = t->info;

            temp->next = t->next;

            if(front == NULL)

            {

                front = temp; rear = temp;

            }

            else

            {

                rear->next = temp;

                rear = temp;

            }

            t = t->next;

        }

    }

    void MakeEmpty()

    {
    	
    	
    	
    	
    	
    	front= rear=NULL;


    }

    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {

if(length()>=5)
{
	return true;
}
else
{
	return false;
}

        /*NodeType<ItemType>* t = front;

        return front == rear;

    }

    int length()

    {

        NodeType<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }

    void Print(/*ofstream &outFile)

    {

NodeType<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";

        cout<<endl;
	t=t->next;
}
    }

    bool push(ItemType x)

    {

        NodeType<ItemType>* temp;

        temp = new NodeType<ItemType>;

        temp->info = x;

        temp->next = NULL;

        if(front == NULL)

        {

            front = temp; //rear = temp;

            return true;

        }

        else if(length() != 5)

        {

            rear->next = temp;

            rear = temp;

            return true;

        }

        else

        {

            return false;

        }

    }

    bool pop(ItemType &x)

    {

        if(IsEmpty())

        {

            return false;

        }
else 
if(front==rear)
{
	free(front);
	front=rear=NULL;
	
	
}
else
{
	NodeType <ItemType>*t = front;

        x = front->info;

        front = front->next;

        delete t;
        return true;
}
        

        

    }

    ItemType Peek(bool &status)

    {

        if(!IsEmpty())

        {
         status = true;
return front->info;
        
            

           // exit(EXIT_FAILURE);

        }
        else
        {
        	status = false;
		}

    }

    ~Stacktwo()

    {
     NodeType <ItemType>*f ;
while(front!=NULL)
{
	f=front->next;
	delete front;
	front=f;
}
 delete rear;

        /*delete front;

       

        front = rear = NULL;

    }

};*/





template<class ItemType>

class Stacktwo

{

    private:

    node<ItemType>* front;



    public:

  


Stacktwo()
	{
		front = NULL;
	}
	// push method to add data element
	void push(ItemType x)
{
	// creating a new node
	node <ItemType>*temp;
	temp = new node<ItemType>();
	// setting data to it
	temp->info = x;

	// add the node in front of list
	if(front == NULL)
	{
		temp->next = NULL;
	}
	else
	{
		temp->next = front;
	}
	front = temp;
}

	
	
	
	void Print(/*ofstream &outFile*/)

    {

node<ItemType>* t = front;
while(t!=NULL)
{
	
	  cout<<t->info<<" ";

        //cout<<endl;
	t=t->next;
}
    }
    
    
    
        int length()

    {

        node<ItemType>* t = front;

        int l = 0;

        while(t != NULL)

        {

            l++;

            t = t->next;

        }

        return l;

    }
    bool IsEmpty()

    {



        return front == NULL;

    }

    bool IsFull()

    {

if(length()>=5)
{
	return true;
}
else
{
	return false;
}
}
ItemType top()
{
	return front->info;
}
void pop()
{
	// if empty
	if(front == NULL)
		cout << "UNDERFLOW\n";
	
	// delete the first element
	else
	{
		node <ItemType>*temp = front;
		front = front->next;
		delete(temp);
	}
}
};

























template<typename T>
void minMaxFunc(T data[5]   )
{
	

	T y;
	 bool callStatus;
	Stackone <T> arrstack;
	Stacktwo <T> liststack;

  

	for(int x=0; x<5;x++)
	{//arrstack.MakeEmpty();
		cout<<endl<<"check num:"<<x<< " ";
		cout<<"the list:";
		liststack.Print();
		cout<<endl;
		cout<<"check data :"<<data[x]<< " ";
		
		
		while(!liststack.IsEmpty() && liststack.top()<data[x])
		{
		cout<<endl<<"peek"<<liststack.top()<<"<"<<data[x];
				arrstack.Push(liststack.top());
				liststack.pop();
	
		
		}
	
			liststack.push(data[x]);

		while(!arrstack.IsEmpty())
		{
			
			liststack.push(arrstack.Peek(callStatus));
				arrstack.Pop(y);
		
		}
		

		
	}
	cout<<endl;
cout<<"Sorted list:"<<endl;
	liststack.Print();
cout<<endl<<"The minimum value is: "<<liststack.top();
	
	
	
 } 













int main()
{
	int numbers[5]={4,1,13,3,5};
	minMaxFunc(numbers);
	
	
	return 0;
}
