#include<iostream>
#include<math.h>
#include<stdlib.h>
#include<string>
#include <fstream>
using namespace std;
template<typename T>
class MinHeap {
  public:
    T * harr; // pointer to array of elements in heap
  int capacity; // maximum possible size of min heap
  int heap_size; // Current number of elements in min heap

  MinHeap(int cap) {
    heap_size = cap;
    capacity = cap;
    harr = new T[cap];
  }

  void printArray(ofstream &output) {
    for (int i = 0; i < heap_size; i++)
    {
	
      cout << harr[i] << " ";
      output<< harr[i] << " "<<endl;
    cout << endl;
    
	}
  }

  int parent(int i) {
    return (i - 1) / 2;
  }

  int left(int i) {
    return (2 * i + 1);
  }

  int right(int i) {
    return (2 * i + 2);
  }
  T getMin() {
    return harr[0];
  }
  void MinHeapify(int i) {
    int l = left(i);
    int r = right(i);
    int smallest = i;
    if (l < heap_size && harr[l] < harr[i])
      smallest = l;
    if (r < heap_size && harr[r] < harr[smallest])
      smallest = r;
    if (smallest != i) {
      swap(harr[i], harr[smallest]);
      MinHeapify(smallest);
    }
  }
  // Method to remove minimum element (or root) from min heap
  T extractMin() {
   /* if (heap_size <= 0)
   {
   	return INT_MAX;
   }*/
      
    if (heap_size == 1) {
      heap_size--;
      return harr[0];
    }

    // Store the minimum value, and remove it from heap
    T root = harr[0];
    harr[0] = harr[heap_size - 1];
    heap_size--;
    MinHeapify(0);
    //printArray();
    //cout <<"--"<<harr[0]<<"--";
    return root;
  }

  void getUnsortedArray() {
    cout << "Enter " << capacity << " no of elements to sort using HEAPSORT" << endl;
    for (int i = 0; i < capacity; i++)
      cin >> harr[i];
  }

  void heapSort(ofstream &output) {
    T *temp;
        temp = new T[capacity];
    for (int j = 0; j < capacity; j++) {
      //cout<<extractMin()<<" ";
      temp[j] = extractMin();
      cout << temp[j] << " ";
      output<< temp[j] << " ";
    }
  }

};

int main() {
  int s;
  cout << "Enter Size of Min Heap" << endl;
  cin >> s; 
  int x=0;
  ofstream output;
  do{
  
  cout<<"Choose frome the menu: "<<endl;
  cout<<"1-To enter integers. "<<endl;
  cout<<"2-To enter real numbers."<<endl;
  cout<<"3-To enter letters."<<endl;
  cout<<"0-To quit."<<endl;
  cin>>x;
  while(x>3||x<0)
  {
  	cout<<"Invalide input.Try again"<<endl;
  	cout<<"Choose frome the menu: "<<endl;
  cout<<"1-To enter integers. "<<endl;
  cout<<"2-To enter real numbers."<<endl;
  cout<<"3-To enter letters."<<endl;
  cout<<"0-To quit."<<endl;
  cin>>x;
  	
  }
  
  if(x==1)
  {
  	
  	output.open("writeintheap.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
  	
  	
  	
  	
  	
  	MinHeap <int > obj(s);
  obj.getUnsortedArray(); 

  cout << "Unsorted Array :" << endl;
  output<< "Unsorted Array :" << endl;
  obj.printArray(output);

  for (int i = s / 2 - 1; i >= 0; i--) {
    obj.MinHeapify(i);
  }

  //cout << "Heapified Array :"<<endl;
  //obj.printArray();

  cout << "Heap Sorted Array :" << endl;
  output<< "Heap Sorted Array :" << endl;
  obj.heapSort(output);
  	
  	cout<<endl;
  	output.close();
  }
  
  if(x==2)
  {
  	
  	output.open("writefloatheap.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	MinHeap <float > obj(s);
  obj.getUnsortedArray(); 

  cout << "Unsorted Array :" << endl;
   output<< "Unsorted Array :" << endl;
  obj.printArray(output);

  for (int i = s / 2 - 1; i >= 0; i--) {
    obj.MinHeapify(i);
  }

  //cout << "Heapified Array :"<<endl;
  //obj.printArray();

  cout << "Heap Sorted Array :" << endl;
    output<< "Heap Sorted Array :" << endl;
  obj.heapSort(output);
  cout<<endl;
  output.close();
  }
  
  
  
  
  if(x==3){
  	
  	
  	output.open("writeletterheap.txt");
        if(output.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	
  	MinHeap <char > obj(s);
  obj.getUnsortedArray(); 

  cout << "Unsorted Array :" << endl;
   output<< "Unsorted Array :" << endl;
  obj.printArray(output);

  for (int i = s / 2 - 1; i >= 0; i--) {
    obj.MinHeapify(i);
  }

  //cout << "Heapified Array :"<<endl;
  //obj.printArray();

  cout << "Heap Sorted Array :" << endl;
    output<< "Heap Sorted Array :" << endl;
  obj.heapSort(output);
  cout<<endl;
 output.close();
  }
  
}while(x!=0);
}
