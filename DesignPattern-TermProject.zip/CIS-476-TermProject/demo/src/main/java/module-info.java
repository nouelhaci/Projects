module mypasssulotion{

    requires  javafx.graphics;
    requires  javafx.fxml;
    requires  javafx.controls;
    requires  java.sql;
    requires java.datatransfer;
    requires java.desktop;

    requires controlsfx;
    requires java.mail;
    //requires java.desktop;
    // requires java.desktop;


    opens sample;


}