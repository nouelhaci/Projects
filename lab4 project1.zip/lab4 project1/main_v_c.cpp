// Lab 4 project 1
/*
   Noureddine Ouelhaci
   Program to practice classes and inheritance
   October 02,2021
*/








#include "Vehicle_c.h"
using namespace std;


int main()
{
	 cout<<"object vehicle-car: "<<endl;
	
	
	 Car testcar;
   Vehicle vehicle;
   
   int checkage=9;
   float checkprice=9.1;
   
    int checkcarage=10;
   float checkcarprice=983.2;
   
   printVehicle(vehicle);
   printCar(testcar);
   
vehicle.setAge(checkage);
vehicle.setPrice(checkprice);
testcar.setRaceCarStatus(true);



printVehicle(vehicle);
printCar(testcar);
cout<<endl<<"Car age: "<<testcar.getAge()<<endl<<"Car price: "<<testcar.getPrice()<<endl;
testcar.setAge(checkcarage);
testcar.setPrice(checkcarprice);

cout<<endl<<"Car age: "<<testcar.getAge()<<endl<<"Car price: "<<testcar.getPrice()<<endl;



return 0;
}
