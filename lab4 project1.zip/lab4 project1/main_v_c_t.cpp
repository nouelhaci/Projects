// Lab 4 project 1
/*
   Noureddine Ouelhaci
   Program to practice classes and inheritance
   October 02,2021
*/








#include "Vehicle_c_t.h"
using namespace std;


int main()
{
	 cout<<"object vehicle-car-truck: "<<endl;
	 Car testcar;
   Vehicle vehicle;
   	 Truck testtruck;
   int checkage=9;
   float checkprice=9.1;
   
    int checkcarage=10;
   float checkcarprice=983.2;
    int checktruckage=29;
   float checkctruckprice=200.21;
   printVehicle(vehicle);
   printCar(testcar);
   printTruck(testtruck);
vehicle.setAge(checkage);
vehicle.setPrice(checkprice);
testcar.setRaceCarStatus(true);
testtruck.setDieselTypeStatus(true);


printVehicle(vehicle);
printCar(testcar);
printTruck(testtruck);
cout<<endl<<"Car age: "<<testcar.getAge()<<endl<<"Car price: "<<testcar.getPrice()<<endl;
cout<<endl<<"Truck age: "<<testtruck.getAge()<<endl<<"Truck price: "<<testtruck.getPrice()<<endl;
testcar.setAge(checkcarage);
testcar.setPrice(checkcarprice);
testtruck.setAge(checktruckage);
testtruck.setPrice(checkctruckprice);
cout<<endl<<"Car age: "<<testcar.getAge()<<endl<<"Car price: "<<testcar.getPrice()<<endl;
cout<<endl<<"Truck age: "<<testtruck.getAge()<<endl<<"Truck price: "<<testtruck.getPrice()<<endl;


return 0;
}
