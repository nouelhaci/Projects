
#ifndef VEHICLE_H_
#define VEHICLE_H_
#include <iostream>
using namespace std;


class Vehicle
{
    protected:

     int age;
     float price;
    public:

    Vehicle()
   {
age = 0;
price = 0;
    }


    void setAge(int age)
    {
     this->age = age;
    }


    void setPrice(float price)
{
this->price = price;
}


    int getAge()
{
    int getage = age;
return getage;
}


float getPrice()
{
float getprice = price;
return getprice;
}
};


class Car : public Vehicle
{
    protected:

    bool raceCarStatus;
    public:

    Car()
{
raceCarStatus = false;
}


    bool getRaceCarStatus()
{
return raceCarStatus;
}


    void setRaceCarStatus(bool raceCarStatus)
{
this->raceCarStatus = raceCarStatus;
}
};


class Truck : public Vehicle
{
    protected:

    bool dieselTypeStatus;
    public:

    Truck()
{
dieselTypeStatus = false;
}
    void setDieselTypeStatus(bool dieselTypeStatus)
{
this->dieselTypeStatus = dieselTypeStatus;
}


bool getDieselTypeStatus()
{
return dieselTypeStatus;
}
};




void printVehicle(Vehicle fvehicle)
{
int age= fvehicle.getAge();
float price =fvehicle.getPrice();

cout<<endl<<"Age: "<<age<<endl<<"Price: "<<price<<endl;
}


void printCar(Car fcar)
{
bool raceCarStatus=fcar.getRaceCarStatus();

cout<<endl<<"Race Car Status: "<<raceCarStatus<<endl;
}


void printTruck(Truck ftruck)
{
bool dieselTypeStatus=ftruck.getDieselTypeStatus();

cout<<endl<<"Diesel Type Status: "<<dieselTypeStatus<<endl;
}

#endif 
