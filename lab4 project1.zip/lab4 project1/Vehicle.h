
#ifndef VEHICLE_H_
#define VEHICLE_H_
#include <iostream>
using namespace std;


class Vehicle
{
    protected:

     int age;
     float price;
    public:

    Vehicle()
   {
age = 0;
price = 0;
    }


    void setAge(int age)
    {
     this->age = age;
    }


    void setPrice(float price)
{
this->price = price;
}


    int getAge()
{
    int getage = age;
return getage;
}


float getPrice()
{
float getprice = price;
return getprice;
}
};







void printVehicle(Vehicle fvehicle)
{
int age= fvehicle.getAge();
float price =fvehicle.getPrice();

cout<<endl<<"Age: "<<age<<endl<<"Price: "<<price<<endl;
}





#endif 
