// Lab 4 project 1
/*
   Noureddine Ouelhaci
   Program to practice classes and inheritance
   October 02,2021
*/








#include "car.h"
using namespace std;


int main()
{
	 cout<<"object car: "<<endl;
    Car testcar;
printCar(testcar);





testcar.setRaceCarStatus(true);


printCar(testcar);


return 0;
}
