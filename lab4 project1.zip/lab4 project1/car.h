

#include <iostream>
using namespace std;





class Car 
{
    protected:

    bool raceCarStatus;
    public:

    Car()
{
raceCarStatus = false;
}


    bool getRaceCarStatus()
{
return raceCarStatus;
}


    void setRaceCarStatus(bool raceCarStatus)
{
this->raceCarStatus = raceCarStatus;
}
};


void printCar(Car fcar)
{
bool raceCarStatus=fcar.getRaceCarStatus();

cout<<endl<<"Race Car Status: "<<raceCarStatus<<endl;
}










