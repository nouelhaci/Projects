// Lab 4 project 1
/*
   Noureddine Ouelhaci
   Program to practice classes and inheritance
   October 02,2021
*/








#include "Vehicle.h"
using namespace std;


int main()
{
   Vehicle vehicle;
   
   int checkage=9;
   float checkprice=9.1;
   cout<<"object vehicle: "<<endl;
   printVehicle(vehicle);
   
   
vehicle.setAge(checkage);
vehicle.setPrice(checkprice);




printVehicle(vehicle);



return 0;
}
