
#include <iostream>
using namespace std;





class Truck 
{
    protected:

    bool dieselTypeStatus;
    public:

    Truck()
{
dieselTypeStatus = false;
}
    void setDieselTypeStatus(bool dieselTypeStatus)
{
this->dieselTypeStatus = dieselTypeStatus;
}


bool getDieselTypeStatus()
{
return dieselTypeStatus;
}
};







void printTruck(Truck ftruck)
{
bool dieselTypeStatus=ftruck.getDieselTypeStatus();

cout<<endl<<"Diesel Type Status: "<<dieselTypeStatus<<endl;
}


