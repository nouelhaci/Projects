// Lab 4 project 1
/*
   Noureddine Ouelhaci
   Program to practice classes and inheritance
   October 02,2021
*/








#include "truck.h"
using namespace std;


int main()
{
	 cout<<"object truck: "<<endl;
	 Truck testtruck;


  printTruck(testtruck);

testtruck.setDieselTypeStatus(true);


printTruck(testtruck);

return 0;
}
