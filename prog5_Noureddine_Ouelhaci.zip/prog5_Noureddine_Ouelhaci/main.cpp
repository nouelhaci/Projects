//Noureddine Ouelhaci
/*
  Project Number 5
   */
#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <map>
using namespace std;





int main()
{
	map<string, double> students;
	string fname,lname,fullname;
	double gpa;
	ifstream infile ("read.txt");
	if(infile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	
	for (int i=0; i<14; i++)      
{
infile>>fname>>lname>>gpa;
fullname=fname+" "+lname;
students.insert(pair<string, double>(fullname,gpa));

}
	
	

	
	infile.close();
	ofstream outfile("write.txt");
	 if(outfile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	for (map<string, double>::iterator it = students.begin(); it != students.end(); ++it) { 
    cout <<left<<setw(20)<<(*it).first <<setw(10) <<(*it).second << '\n'; 
    outfile<<left<<setw(20)<<(*it).first <<setw(10) <<(*it).second << '\n'; 
  } 
	
	
	
	
	
	
	return 0;
}

