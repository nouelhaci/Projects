#include<stdlib.h>
#include<iostream>
#include<string>
#include<iostream>
#include <time.h>
#include <fstream>
using namespace std;
template <class T>
struct randomNode 
{ T randomValue;    // uses the template data type 
   int occurrences;
   randomNode * next;
};

 struct AscendingOrderedNode
{ int orderedValue;
   AscendingOrderedNode * next;
};


template <class T>
class tenForward {
	private:
       T randomValues;
       
       	randomNode<int>* tenhead;
	AscendingOrderedNode* tensortedlist;
      
   public:
	
	tenForward(T x, randomNode<int>* head, AscendingOrderedNode* sortedlist)
	{
		randomValues=x;
	tenhead=head;
	tensortedlist=sortedlist;
	}
	~tenForward(){
		
		randomNode<int>* deletePtrtenhead;
	

while (tenhead != NULL)
    {
       deletePtrtenhead = tenhead;   // assign address to free memory               
       tenhead = tenhead -> next; // move down list, make sure to avoid lost objects
       delete deletePtrtenhead; // call heap management to free memory
    }
    
    
    
    
    
    AscendingOrderedNode* deletePtrtensortedlist;
    while (tensortedlist != NULL)
    {
       deletePtrtensortedlist = tensortedlist;   // assign address to free memory               
       tensortedlist = tensortedlist -> next; // move down list, make sure to avoid lost objects
       delete deletePtrtensortedlist; // call heap management to free memory
    }
	};
	void add(randomNode<int>** head, T data, AscendingOrderedNode** sortedlist, ofstream &outFile)
{
	
	
	
	if(data<11)
	{
		 cout<<endl<<"Random numbe:"<<data<<endl;
		 outFile<<endl<<"Random numbe:"<<data<<endl;
	}
  else
  {
  	
  	cout<<endl<<"Random letter:"<<data<<endl;
  	outFile<<endl<<"Random letter:"<<data<<endl;
  }
    randomNode<int>* newNode = new randomNode<int>;
    newNode->next = (*head);
   

   bool same=false;
   randomNode<int>* position = new randomNode<int>;
		position=(*head);

 while (position!=NULL)
 {
    if(position->randomValue==data)
    {
    	same=true;
    	position->occurrences=position->occurrences+1;
	
	}
   position = position->next;
}
 

   if(!same)
   {
   	cout<<data<<"not in list"<<endl;
   	outFile<<endl<<"Random letter:"<<data<<endl;
   	newNode->randomValue = data;
    	newNode->occurrences=1;
    	(*head) = newNode;
   }
   	else if(same)
	   {
	   	cout<<data<<"already in list"<<endl;
	   	outFile<<data<<"already in list"<<endl;
		   }
		   
		   
		   
		   
		   
		   
		   
	AscendingOrderedNode* newNodesort = new AscendingOrderedNode;
    newNodesort->next = (*sortedlist);
   

   bool samesort=false;
   AscendingOrderedNode* positionsort = new AscendingOrderedNode;
		positionsort=(*sortedlist);

 while (positionsort!=NULL)
 {
    if(positionsort->orderedValue==data)
    {
    	samesort=true;
    
	
	}
   positionsort = positionsort->next;
}
 

   if(!samesort)
   {
   	
   	newNodesort->orderedValue = data;
    	
    	(*sortedlist) = newNodesort;
   }
  
		   
		   
		   
		   
		   
		   
		   
		   	
  
}
 

void printList(randomNode<int>* head,ofstream &outFile)
{
   char x;
    	randomNode <int>*position;
		position=head;
		
		cout<<"Random order:"<<endl;
		outFile<<"Random order:"<<endl;
		if (position == NULL)    
  { cout << "No data in list" << endl;
  outFile<< "No data in list" << endl;}
else
 {while (position!=NULL)
 {
 if(position->randomValue<11)
 {
 	 cout <<position->randomValue<<"  " ; 
   outFile<<position->randomValue<<"  " ; 
 	
 }
  else
   {
   	x=(char) position->randomValue;
   	 cout <<x<<" - " ;
   	 outFile<<x<<" - " ;
   }
       cout <<position->occurrences<<" occurrence"<<endl;      
            outFile<<position->occurrences<<" occurrence"<<endl; 
            
            
   position = position->next;
}
 }
}
 

void printsortedList(AscendingOrderedNode* head,ofstream &outFile)
{
   char x;
    	AscendingOrderedNode* position;
		position=head;
		
		cout<<"Ordered ascending:"<<endl;
		outFile<<"Ordered ascending:"<<endl;


 {while (position!=NULL)
 {
 if(position->orderedValue<11)
 {
 	cout <<position->orderedValue<<" " ; 
 	outFile<<position->orderedValue<<" " ; 
 }
   
  else{
  	x=(char) position->orderedValue;
   	 cout <<x<<"  " ;
  	
  	outFile<<x<<"  " ;
  }
            
            
            
            
   position = position->next;
}
 }
}









void sortList(AscendingOrderedNode** sortedlist)
{
   
  
  
    
    
    
    
    AscendingOrderedNode* prev = (*sortedlist);
    AscendingOrderedNode* curr = (*sortedlist)->next;
 
   
    while (curr != NULL)
    {
   
        if (curr->orderedValue < prev->orderedValue)
        {
            
            prev->next = curr->next;
 
           
            curr->next = (*sortedlist);
            (*sortedlist) = curr;
 
         
            curr = prev;
        }
 
      
        else
            prev = curr;
 
    
        curr = curr->next;
    }
}
	
	

	
	
	int getCount(randomNode<int>* head) 
{ 
    int count = 0; 
    randomNode<int>* current = head; 
    while (current != NULL) 
    { 
        count++; 
        current = current->next; 
    } 
    return count; 
} 
	

	
	
}; 













template <class T>
class tenBackward
{
	
	private:
       T randomValues;
      
   public:
   	tenBackward(randomNode<int>* old_linked_list, randomNode<int> *&new_linked_list) {
	randomNode<int>* current = old_linked_list;
	randomNode<int>* current2 = NULL;
	randomNode<int>* temp = NULL;
	new_linked_list = NULL;

	while (current != NULL) {
		temp = new randomNode<int>;
		temp->randomValue = current->randomValue;
		temp->occurrences = current->occurrences;
		temp->next = NULL;
		if (new_linked_list == NULL) {
			new_linked_list = temp;
			current2 = new_linked_list;
		}
		else {
			current2->next = temp;
			current2 = current2->next;
		}
		current = current->next;
	}
	
	
	
}



void sortList(randomNode<int>** sortedlist)
{
   
  
  
    
    
    
    
    randomNode<int>* prev = (*sortedlist);
    randomNode<int>* curr = (*sortedlist)->next;
 
   
    while (curr != NULL)
    {
   
        if (curr->randomValue > prev->randomValue)
        {
           
            prev->next = curr->next;
 
         
            curr->next = (*sortedlist);
            (*sortedlist) = curr;
 
         
            curr = prev;
        }
 
      
        else
            prev = curr;
 
    
        curr = curr->next;
    }
}


void add(randomNode<int>* head, randomNode<int>** sortedlist,ofstream &outFile)
{
   char x;
    randomNode<int>* newNode = new randomNode<int>;
    newNode->next = (*sortedlist);
   

  
  


newNode->randomValue = head->randomValue;



if(head->randomValue<11)
{

    	cout<<endl<<"Random numbe:"<<head->randomValue<<endl;
    	outFile<<endl<<"Random numbe:"<<head->randomValue<<endl;}
    	else{
    		x=(char)head->randomValue;
    		cout<<endl<<"Random letter:"<<x<<endl;
    		outFile<<endl<<"Random letter:"<<x<<endl;
		}
    	(*sortedlist) = newNode;

head = head->next;



 
		   
		   
		   
		   
		   
		   
		   

  
		   
		   
		   
		   
		   
		   
		   
		   	
  
}








void ptintdescendinglist(randomNode<int>* head,ofstream &outFile)
     {
     	
     	char x;
  randomNode <int>*position;
		position=head;
		
		cout<<"Ordered descendin:"<<endl;
		outFile<<"Ordered descendin:"<<endl;
		if (position == NULL)    
  { cout << "No data in list" << endl;
  outFile<< "No data in list" << endl;
  }
else
 {while (position!=NULL)
 {
 
 
 if(position->randomValue<11){
 
   cout <<position->randomValue<<" "; 
   outFile<<position->randomValue<<" "; }
   else
   {
   	x=(char)position->randomValue;
   	cout<<x<<" ";
   	outFile<<x<<" ";
   }
 
   
            
            
            
            
   position = position->next;
}
 }}

   //~tenBackward();
};







	










int main()
{
	
	ofstream outFile;
        outFile.open("word.txt");
        if(outFile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	
	
	int randomNbr=0, listSize=0, total=0;
	srand (time(NULL));
	
	
	
	randomNode<int>* head=NULL;
	AscendingOrderedNode* sortedlist=NULL;
	tenForward<int>inst1(0, head, sortedlist);
	
	
	while(listSize!=10)
	{
		randomNbr=rand() % 10 + 1;
		inst1.add(&head,randomNbr,&sortedlist,outFile );
		inst1.printList(head,outFile);
	inst1.sortList(&sortedlist);
		inst1.sortList(&sortedlist);
		
		inst1.printsortedList(sortedlist,outFile);
		listSize=inst1.getCount(head);
		total++;
	
	}
	
	cout<<endl<<"Total number of random numbers generated to get the full list of values 1 � 10 is:"<<total<<endl;
	
	randomNode<int>* copyhead=NULL;
	randomNode<int>* copyheadse=NULL;
	
	tenBackward<int>inst2(head,copyhead);
	
	
	while (copyhead!=NULL )
	{
		inst2.add(copyhead,&copyheadse,outFile);
		
		for(int x=0; x<10;x++)
		{
		
	inst2.sortList(&copyheadse);}
	
	
	inst2.ptintdescendinglist(copyheadse,outFile);
	
	
	copyhead=copyhead->next;
	}
	
	
	
	
	
		randomNode<int>* headletters=NULL;
	AscendingOrderedNode* sortedlistletters=NULL;
	tenForward<char>inst3(0,headletters, sortedlistletters);
	
	char letter;
	int countletters=0, totalletters=0,listSizeletters=0;
	
	
	
	
	
	
	
	cout<<endl;
	while(listSizeletters!=10)
	{
		cout<<"Please, enter a letter:";
		cin>>letter;
	
			letter=tolower(letter);
		
	while(!isalpha(letter))
	{
		
		cout<<"invalide input. try again."<<endl;
		
		cout<<endl<<"Please, enter a letter:";
		cin>>letter;
	}
		
		
		
		
		
	
		inst3.add(&headletters,letter,&sortedlistletters,outFile );
		inst3.printList(headletters,outFile);
	inst3.sortList(&sortedlistletters);
		inst3.sortList(&sortedlistletters);
		
		inst3.printsortedList(sortedlistletters,outFile);
		listSizeletters=inst3.getCount(headletters);
		totalletters++;
	
	}
	
	cout<<endl<<"Total number of random numbers generated to get the full list of 10 letters is:"<<totalletters<<endl;
	
	
	
	
	
	
	randomNode<int>* copyheadletters=NULL;
	randomNode<int>* copyheadseletters=NULL;
	
	tenBackward<char>inst4(headletters,copyheadletters);
	
	
	while (copyheadletters!=NULL )
	{
		inst4.add(copyheadletters,&copyheadseletters,outFile);
		
		for(int x=0; x<10;x++)
		{
		
	inst4.sortList(&copyheadseletters);}
	
	
	inst4.ptintdescendinglist(copyheadseletters,outFile);
	
	
	copyheadletters=copyheadletters->next;
	}
	
	
	
	
	
	
	
	


	inst1.~tenForward();
		inst3.~tenForward();
		
	outFile.close();
	return 0;
}
