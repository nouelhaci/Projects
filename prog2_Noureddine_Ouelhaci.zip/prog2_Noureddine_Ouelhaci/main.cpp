//Noureddine Ouelhaci
/*
   Second Project
   */

#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <string>
#include <cstring>
using namespace std;
void order(char** pp1, char** pp2) //orders two pointers
{ 

  if (0 < strcmp(*pp1, *pp2)) {
        char* pchTemp = *pp1;
        *pp1 = *pp2;
        *pp2 = pchTemp;
      }
}
void bsort(char** pp, int n) 
{

for (int j = 0; j < n -1; j++) {
    for (int i = 0; i < n -1; i++) {
    	
    order(pp+i, pp+i+1);
    	
    }
  }
}

int main()
{
	
	
	char* studentname[25]; 
	ifstream infile ("student.txt");
	if(infile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
int i=0;
string fname_take;
string lname_take;
string fullname_take;
for (int i=0; i<25; i++)      
{
	infile>>fname_take>>lname_take;
	fullname_take=fname_take+ " " +lname_take;
	studentname[i] = new char[fullname_take.size() + 1];
	 strcpy(studentname[i],fullname_take.c_str());

}
infile.close();
ofstream outfile("record.txt");
	 if(outfile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}

cout<<"Student list before sorting:"<<endl<<endl;;
cout<<"student name"<<endl<<endl;
outfile<<"Student list before sorting:"<<endl<<endl;
outfile<<"student name"<<endl<<endl;
for(int i=0;i<25;i++)
{cout<<studentname [i]<<"\n";
outfile<<studentname [i]<<"\n";}

bsort(studentname, 25); 

cout<<endl;
cout<<"======================================="<<endl;
cout<<endl;
cout<<"Student list after sorting:"<<endl<<endl;
cout<<"student name"<<endl<<endl;
outfile<<endl;
outfile<<"======================================="<<endl;
outfile<<endl;
outfile<<"Student list after sorting:"<<endl<<endl;
outfile<<"student name"<<endl<<endl;
for(int i=0;i<25;i++)
{cout<<studentname [i]<<"\n";
outfile<<studentname [i]<<"\n";}
	

	return 0;
}

