// ConsoleApplication1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

//Noureddine Ouelhaci
/*
   Second Project
   */

#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
#include <string>
#include <cstring>

using namespace std;
void order(char** pp1, char** pp2) //orders two pointers
{

    if (0 < strcmp(*pp1, *pp2)) {
        char* pchTemp = *pp1;
        *pp1 = *pp2;
        *pp2 = pchTemp;
    }
}
void bsort(char** pp, int n)
{

    for (int j = 0; j < n - 1; j++) {
        for (int i = 0; i < n - 1; i++) {

            order(pp + i, pp + i + 1);

        }
    }
}

int main()
{


    char* studentname[25];
    ifstream infile("student.txt");
    if (infile.fail())
    {
        cerr << "Error Opening File" << endl;
        exit(1);
    }
    int i = 0;
    string fname_take;
    string lname_take;
    string fullname_take;
    for (int i = 0; i < 25; i++)
    {
        infile >> fname_take >> lname_take;
        fullname_take = fname_take + " " + lname_take;
        studentname[i] = new char[fullname_take.size() + 1];
        strcpy_s (studentname[i], strlen(fullname_take.c_str()) + 1,fullname_take.c_str());

    }
    infile.close();
    ofstream outfile("record.txt");
    if (outfile.fail())
    {
        cerr << "Error Opening File" << endl;
        exit(1);
    }

    cout << "Student list before sorting:" << endl << endl;;
    cout << "student name" << endl << endl;
    outfile << "Student list before sorting:" << endl << endl;
    outfile << "student name" << endl << endl;
    for (int i = 0; i < 25; i++)
    {
        cout << studentname[i] << "\n";
        outfile << studentname[i] << "\n";
    }

    bsort(studentname, 25);

    cout << endl;
    cout << "=======================================" << endl;
    cout << endl;
    cout << "Student list after sorting:" << endl << endl;
    cout << "student name" << endl << endl;
    outfile << endl;
    outfile << "=======================================" << endl;
    outfile << endl;
    outfile << "Student list after sorting:" << endl << endl;
    outfile << "student name" << endl << endl;
    for (int i = 0; i < 25; i++)
    {
        cout << studentname[i] << "\n";
        outfile << studentname[i] << "\n";
    }


    return 0;
}


// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu

// Tips for Getting Started: 
//   1. Use the Solution Explorer window to add/manage files
//   2. Use the Team Explorer window to connect to source control
//   3. Use the Output window to see build output and other messages
//   4. Use the Error List window to view errors
//   5. Go to Project > Add New Item to create new code files, or Project > Add Existing Item to add existing code files to the project
//   6. In the future, to open this project again, go to File > Open > Project and select the .sln file
