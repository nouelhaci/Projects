




#include<stdlib.h>
#include <iostream> 
#include <fstream> 
#include <string> 
#include <iomanip>  
using namespace std;
class student
{
   private:
   
         string name;
           string classs;
             float gpa; 

public:
   student(){
   };
    
   /* void setname(string a );
    void setclass(string b ); 
   
    void setgpa(string c);*/ 
    char getclass();
    string getname();
   //friend void print(student x );
 float getgpa();
   
    friend ostream & operator << (ostream &out, const student &c);
    friend ifstream & operator >> (ifstream &read,  student &c);
    friend ofstream & operator >> (ofstream &write,  student &c);
   
   
};




ostream & operator << (ostream &out, const student &c)
{
	out<<left<<setw(20)<<c.name<<setw(10)<<c.classs<<setw(10)<<c.gpa<<endl;
    return out;
}
 
ifstream & operator >> (ifstream &read,  student &c)
{
	string fname_take;
string lname_take;
read>>fname_take;
read>>lname_take;
string fullname_take=fname_take+ " " +lname_take;
    c.name=fullname_take;
	read>>c.classs;
	read>>c.gpa;
    return read;
}

ofstream & operator >> (ofstream &write,  student &c)
{
		write<<left<<setw(20)<<c.name<<setw(10)<<c.classs<<setw(10)<<c.gpa<<endl;
    return write;
}







/*void student:: setname( string a) 
   {
   //	cout<<"check a:"<<a<<endl;
   	name=a;
  // x.name.assign(a);
  //cout<<"check name:"<<x.name<<endl;
   }
 
void student:: setclass(string b) 
   {
  // cout<<"check b:"<<b<<endl;
   classs=b;
   //x.classs.assign(b);
  // cout<<"check class:"<<x.classs<<endl;
   
   }
 
void student:: setgpa(string c ) 
{
	//cout<<"check c:"<<c<<endl;
	gpa=c;
//x.gpa.assign(c);
//cout<<"check gpa:"<<x.gpa<<endl;
}*/
 
 
char student:: getclass()
{return classs[1];
   }
   
string student::getname()
{return name;
}
float student::getgpa()
{return gpa;
}
/*void print(student x )
   {
   	
   	cout<<x.name<<"\t\t"<<x.classs<<"\t\t\t"<<x.gpa<<endl;
 }
*/
void swap (student *stdt1, student *stdt2)
{
student temp = *stdt1;
*stdt1 = *stdt2; 
*stdt2 = temp;
}



int main()
{
	
	
	student students[25], fresh[25], soph[25], junior[25], senior[25]; 

/*string fullname_take;
string fname_take;
string lname_take;
string class_take;
string gpa_take;*/

	ifstream infile ("student.txt");
	if(infile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	


int i=0;

for (int i=0; i<25; i++)      
{
infile>>students[i];
 //infile>>fname_take>>lname_take>>class_take>>gpa_take;
/*fullname_take=fname_take+ " " +lname_take;
students[i].setname(fullname_take);
students[i].setclass(class_take);
students[i].setgpa(gpa_take);*/
   /* setname(students[i],fullname_take );
    setclass(students[i],class_take);
	setgpa(students[i], gpa_take );*/
//cout<<fname_take<<lname_take<<class_take<<gpa_take<<endl;
}

infile.close();




	
	for (int i=0; i<25; i++)
{

for (int j = i+1; j <25 ; j++)
{
if ( students [j].getname() < students [i].getname())
{
 
swap (students [i],students [j]) ;
}
   }   
}
	
	
/*for(int i=0;i<25;i++)
{cout<<students [i].getname()<<"\n";}*/
	
	
	
	
int freshh=0, sophh=0, juniorr=0,seniorr=0; 
for (int i=0; i<25; i++)
{
switch (students [i].getclass())
{
 
case 'r': 
fresh [freshh++] = students [i];
break;
case 'o': 
soph [sophh++] = students [i];
break;
case 'u': 
junior [juniorr++] =students [i];
break;
case 'e': 
senior[seniorr++] =students [i];
break;
}

}
	
	ofstream outfile("record.txt");
	 if(outfile.fail())
        {
        	cerr<<"Error Opening File"<<endl;
        	exit(1);
		}
	
	
	
	float total=0;
int count=0;
float avrg=0;
	cout<<"A. The sorted master list with the average GPA of the entire college"<<endl<<endl;
	outfile<<"A. The sorted master list with the average GPA of the entire college"<<endl<<endl;
	cout<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
	outfile<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
	for (int i=0; i<25; i++)
{
	if(! students [i].getname().empty())
	{
		cout << students [i];
		outfile<< students [i];
		total+=students [i].getgpa();
		count++;
	}
	
	//print(students [i] );
}
avrg=total/count;
cout<<endl;
cout<<fixed<<setprecision(2);
outfile<<fixed<<setprecision(2);
cout<<"The average GPA of the entire college :"<<avrg<<endl;
outfile<<endl;
outfile<<"The average GPA of the entire college :"<<avrg<<endl;
cout<<endl;
outfile<<endl;
	 total=0;
 count=0;
 avrg=0;
	cout<<"B. The freshman list with the average GPA of the freshmen."<<endl<<endl;
	outfile<<"B. The freshman list with the average GPA of the freshmen."<<endl<<endl;
	cout<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
	outfile<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
		for (int i=0; i<25; i++)
{
	
	if(! fresh [i].getname().empty())
	{
		cout << fresh [i];
		outfile << fresh [i];
		total+=fresh [i].getgpa();
		count++;
	}
	
	//print(fresh [i] );
}
avrg=total/count;
cout<<endl;
cout<<"The average GPA of the freshman :"<<avrg<<endl;
outfile<<endl;
outfile<<"The average GPA of the freshman :"<<avrg<<endl;
cout<<endl;
outfile<<endl;
	 total=0;
 count=0;
 avrg=0;
	cout<<"C. The sophomore list with the average GPA of the sophomores."<<endl<<endl;
	cout<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
	outfile<<"C. The sophomore list with the average GPA of the sophomores."<<endl<<endl;
	outfile<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
			for (int i=0; i<25; i++)
{
	
	
	if(! soph [i].getname().empty())
	{
		cout << soph [i];
		outfile << soph [i];
		total+=soph [i].getgpa();
		count++;
	}
	
	//print(soph [i] );
}
avrg=total/count;
cout<<endl;
cout<<"The average GPA of the sophomores :"<<avrg<<endl;
outfile<<endl;
outfile<<"The average GPA of the sophomores :"<<avrg<<endl;
cout<<endl;
outfile<<endl;
	 total=0;
 count=0;
 avrg=0;
cout<<"D. The junior list with the average GPA of the juniors."<<endl<<endl;
cout<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
outfile<<"D. The junior list with the average GPA of the juniors."<<endl<<endl;
outfile<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
				for (int i=0; i<25; i++)
{
	if(! junior [i].getname().empty())
	{
			cout << junior [i];
			outfile << junior [i];
			total+=junior [i].getgpa();
		count++;
	}

	//print(junior [i] );
}
avrg=total/count;
cout<<endl;
cout<<"The average GPA of the juniors :"<<avrg<<endl;
outfile<<endl;
outfile<<"The average GPA of the juniors :"<<avrg<<endl;
cout<<endl;
outfile<<endl;
	 total=0;
 count=0;
 avrg=0;
	cout<<"E. The senior list with the average GPA of the seniors."<<endl<<endl;
	cout<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
		outfile<<"E. The senior list with the average GPA of the seniors."<<endl<<endl;
	outfile<<left<<setw(20)<<"Name"<<setw(10)<<"Class"<<setw(10)<<"GPA"<<endl;
			for (int i=0; i<25; i++)
{
	if(! senior [i].getname().empty())
	{
		cout << senior [i];
		outfile << senior [i];
		total+=senior [i].getgpa();
		count++;
	}
	
//	print(senior [i] );
}
avrg=total/count;
cout<<endl;
cout<<"The average GPA of the seniors :"<<avrg<<endl;
outfile<<endl;
outfile<<"The average GPA of the seniors :"<<avrg<<endl;	
	
	
	
	
	
	
	
	
	
	
	
	
	return 0;
}

