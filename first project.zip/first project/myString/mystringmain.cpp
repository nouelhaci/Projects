// First Project
/*
   Noureddine Ouelhaci
   program  to creat my own version of a string class named myString 
   October 13,2021
*/
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
#include "myString.h"

int main(){
	
	
	ofstream file;
	
	file.open("myStringLog.txt");
	if(file.fail())
	{
		cerr<<"Error openning file"<<endl;
		exit(1);
	}
	
	
	
	
	
	
	
   bool methodStatus=NULL;
    myString instance1;
    file<<"program action         create myString instance1";
    cout<<"program action         create myString instance1";
    if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance1 contains empty string";
    	cout<<"\nmyString instance1 contains empty string";
	}
	myString instance2;
	file<<"\nprogram action         create myString instance2";
    cout<<"\nprogram action         create myString instance2";
	if(instance2.emptyString()==true)
    {
    	file<<"\nmyString instance2 contains empty string";
    	cout<<"\nmyString instance2 contains empty string";
	}
	
	
   instance1.setString("CIS 200 IS FUN!",methodStatus);
   if(methodStatus==true)
   {
   		file<<"\nuser action set instance1 value to"<<instance1.getString();
    	cout<<"\nuser action set instance1 value to"<<instance1.getString();
   	    file<<"\nmyString instance1 contains "<<instance2.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance2.printString();
    	file<<"\nThe size of instance1 is "<<instance1.size();
    	cout<<"\nThe size of instance1 is "<<instance1.size();
    	file<<"\nuser action display a character at 1 :"<<instance1.charAt(1,methodStatus);
    	cout<<"\nuser action display a character at 1 :"<<instance1.charAt(1,methodStatus);
    	if(methodStatus==false)
    	{
    		file<<"\nError invalide data";
    	cout<<"\nError invalide data";
		}
   	file<<"\nuser action display a character at 11 :"<<instance1.charAt(11,methodStatus);
    	cout<<"\nuser action display a character at 11 :"<<instance1.charAt(11,methodStatus);
    	if(methodStatus==false)
    	{
    		file<<"\nError invalide data";
    	cout<<"\nError invalide data";
		}
			file<<"\nuser action display a character at -1 :"<<instance1.charAt(-1,methodStatus);
    	cout<<"\nuser action display a character at -1 :"<<instance1.charAt(-1,methodStatus);
    	if(methodStatus==false)
    	{
    		file<<"  Error invalide data";
    	cout<<"  Error invalide data";
		}
   }
   else
   {
   	file<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	cout<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	file<<"\nmyString instance1 contains empty string";
    	cout<<"\nmyString instance1 contains empty string";
   }
   
   
   instance2.setString("CIS 200 IS THE BEST CLASS EVER",methodStatus);
   if(methodStatus==true)
   {
   		file<<"\nuser action set instance2 value to"<<instance2.getString();
    	cout<<"\nuser action set instance2 value to"<<instance2.getString();
   	    file<<"\nmyString instance2 contains "<<instance2.getString();
   	   
    	cout<<"\nmyString instance2 contains ";
   	instance2.printString();
   }
   else
   {
   	file<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	cout<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	
    	if(instance2.emptyString()==true)
    {
    	file<<"\nmyString instance2 contains empty string";
    	cout<<"\nmyString instance2 contains empty string";
	}
   }
   
   
   instance1.initString();
   
   	file<<"\nuser action initialize instance1";
    	cout<<"\nuser action initialize instance1";
   
   if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance1 contains empty string";
    	cout<<"\nmyString instance1 contains empty string";
	}
  instance1.setString("CIS 200 IS FUN! and great",methodStatus);
  if(methodStatus==true)
   {
   		file<<"\nuser action set instance1 value to"<<instance1.getString();
    	cout<<"\nuser action set instance1 value to"<<instance1.getString();
   	    file<<"\nmyString instance1 contains "<<instance2.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance2.printString();
    	file<<"\nThe size of instance1 is "<<instance1.size();
    	cout<<"\nThe size of instance1 is "<<instance1.size();
    	if(instance1.fullString()==true)
    	{
    		file<<"\nmyString instance1 contains full string";
    	cout<<"\nmyString instance1 contains full string";
		}
   	
   }
   else
   {
   	file<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	cout<<"\nstance2 not updated, ERROR: user data > 25 characters";
    	
    		if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance1 contains empty string";
    	cout<<"\nmyString instance1 contains empty string";
	}
   }
  instance1.setString("CIS 200",methodStatus);
  if(methodStatus==true)
   {
   		file<<"\nuser action set instance1 value to"<<instance1.getString();
    	cout<<"\nuser action set instance1 value to"<<instance1.getString();
   }
   else
   {
   	file<<"\ninstance1 not updated, ERROR: user data > 25 characters";
    	cout<<"\ninstance1 not updated, ERROR: user data > 25 characters";
    	
    		if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance1 contains empty string";
    	cout<<"\nmyString instance1 contains empty string";
	}
   }
  
  
  instance2.setString("CIS 200",methodStatus);
   if(methodStatus==true)
   {
   		file<<"\nuser action set instance2 value to"<<instance2.getString();
    	cout<<"\nuser action set instance2 value to"<<instance2.getString();
   }
   else
   {
   	file<<"\ninstance2 not updated, ERROR: user data > 25 characters";
    	cout<<"\ninstance2 not updated, ERROR: user data > 25 characters";
    	
    		if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance2 contains empty string";
    	cout<<"\nmyString instance2 contains empty string";
	}
   }
  
  
     if(instance1.compareString(instance2)==true)
     {
     	file<<"\nuser action compare instance1 and instance2: they are equal";
    	cout<<"\nuser action compare instance1 and instance2: they are equal";
	 }
	 else
	 {
	 	file<<"\nuser action compare instance1 and instance2: they are not equal";
    	cout<<"\nuser action compare instance1 and instance2: they are not equal";
	 }
  instance2.setString("CIS 200+",methodStatus);
   if(methodStatus==true)
   {
   		file<<"\nuser action set instance2 value to"<<instance2.getString();
    	cout<<"\nuser action set instance2 value to"<<instance2.getString();
   }
   else
   {
   	file<<"\ninstance2 not updated, ERROR: user data > 25 characters";
    	cout<<"\ninstance2 not updated, ERROR: user data > 25 characters";
    	
    		if(instance1.emptyString()==true)
    {
    	file<<"\nmyString instance2 contains empty string";
    	cout<<"\nmyString instance2 contains empty string";
	}
   }
  
  if(instance1.compareString(instance2)==true)
     {
     	file<<"\nuser action compare instance1 and instance2: they are equal";
    	cout<<"\nuser action compare instance1 and instance2: they are equal";
	 }
	 else
	 {
	 	file<<"\nuser action compare instance1 and instance2: they are not equal";
    	cout<<"\nuser action compare instance1 and instance2: they are not equal";
	 }
	 
	 instance2.setString("CIS 200 replaced",methodStatus);
	 
	 instance1.replWholeString(instance2,methodStatus);
  if(methodStatus==true)
     {
     	file<<"\nuser action replace instance1 with instance2";
    	cout<<"\nuser action replace instance1 with instance2";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
	   instance1.setString("CIS 200 ",methodStatus);
	    instance2.setString("IS FUN",methodStatus);
	 instance1.addStart(instance2,methodStatus);
	 
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action add instance2 to the biginning of instance1";
    	cout<<"\nuser action add instance2 to the biginning of instance1";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
	 	 	  instance1.setString("�CIS 200 IS THE BEST CLASS ",methodStatus);
	    instance2.setString("CIS 200 IS THE BEST",methodStatus);
	 instance1.addStart(instance2,methodStatus); 
	 
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action add instance2 to the biginning of instance1";
    	cout<<"\nuser action add instance2 to the biginning of instance1";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
	 
	  instance1.setString("CIS 200 ",methodStatus);
	    instance2.setString("IS FUN",methodStatus);
	 instance1.addEnd(instance2,methodStatus);
	 
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action add instance2 to the end of instance1";
    	cout<<"\nuser action add instance2 to the end of instance1";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
	 	  instance1.setString("CIS 200 IS THE BEST CLASS ",methodStatus);
	    instance2.setString("CIS 200 IS THE BEST",methodStatus);
	 instance1.addEnd(instance2,methodStatus); 
	 
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action add instance2 to the end of instance1";
    	cout<<"\nuser action add instance2 to the end of instance1";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
    instance1.setString("CIS 200 ",methodStatus);
	    instance2.setString("IS FUN",methodStatus);

	 instance1.replPartString(instance2,2,methodStatus);
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action replace instance1 with part of instance2";
    	cout<<"\nuser action replace instance1 with part of instance2";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
   
   
   
   instance1.setString("CIS 200 ",methodStatus);
	    instance2.setString("IS FUN",methodStatus);

	 instance1=instance2.partString(2,3,methodStatus);
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action set instance1 to part of instance2";
    	cout<<"\nuser action set instance1 to part of instance2";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
   
   
   instance1.setString("CIS 200 ",methodStatus);
	    instance2.setString("IS FUN",methodStatus);

	 instance1=instance2.partString(-2,10,methodStatus);
	 
	 if(methodStatus==true)
     {
     	file<<"\nuser action set instance1 to part of instance2";
    	cout<<"\nuser action set instance1 to part of instance2";
    	file<<"\nmyString instance1 contains "<<instance1.getString();
   	   
    	cout<<"\nmyString instance1 contains ";
   	instance1.printString();
    	
	 }
	 else
	 {
	 	file<<"\nERROR: user data > 25 characters";
    	cout<<"\nERROR: user data > 25 characters";
	 }
   
  
 
   
   file.close();
   return 0;
}

