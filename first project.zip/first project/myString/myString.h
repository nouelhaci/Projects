
#include<stdlib.h>
#define MAXSIZE 25
class myString{
   private:
       char  *makeString;
       int length;
       bool methodStatus;
      
   public:
       myString(){
          
         makeString=(char *)malloc(sizeof(char)*MAXSIZE);
           makeString[0]='\0';
           length=0;
           methodStatus=NULL;
       }
       
        string getString(){
           string take="";
           char takechar;
           int x=0;
           while((takechar=makeString[x])!='\0'){
               take+=takechar;
               x++;
           }
           return take;
       }
       
       
       void setString(string take, bool & methodStatus){
           
           int takelength=take.length();
           if(takelength>25){
              
              methodStatus=false;
               return;
           }
           else
           {
           	methodStatus=true;
           	int x;
           	for( x=0;x<takelength;x++){
               makeString[x]=take.at(x);
           }
           makeString[x]='\0';
           length=x;
           	
           	
		   }
           
       }
       
       void initString(){
           length=0;
           makeString[0]='\0';
       }
       
       int size(){
           return length;
       }
       
      
       
       void printString(){
           cout<<makeString;
       }
       
        bool emptyString(){
        	
        	if(length==0)
        	{
        		return true;
			}
        	else return false;
        	
        	
        	
   
       }
      
       bool fullString(){
       	
       	if(length==MAXSIZE)
       	{
       		return true;
		   }
       	else 
       	{
       		return false;
		   }
       	
       	
     
       }
        char charAt(int pos, bool & methodStatus){
          
		  
		   if(pos<0 || pos>=length)
               {
               	methodStatus=false;
               	return ' ';
			   }
		  else 
		  {
		  	methodStatus=true;
		  	return makeString[pos];
		  }
		  
		  
		  
		
       } 
       
       
       
       bool compareString(myString compar){
          
		  int count=0;
		  
		   for(int x=0;x<length;x++){
               if(makeString[x]==compar.charAt(x,methodStatus))
               {
               	count++;
               
			   }
               
           }
           
           
           	if(count==length&&compar.size()==length)
           	{
           			return true;
			   }
		   else
		   {
		   		return false;
		   }
           
       }
    
       
       
       
       
       void addStart(myString add, bool & methodStatus){
          
		   int takelength=length+add.size();
		   char *takechar=new char[takelength];
           if(takelength>25){
              methodStatus=false;
               return;
           }
           else
           {
           	methodStatus=true;
           	int x,y,z;
           	 for( x=0;x<add.size();x++)
           	 {
           	 	takechar[x]=add.charAt(x,methodStatus);
				}
               
           for( y=0;y<length;y++,x++)
           {
           	takechar[x]=makeString[y];
		   }
               
           for( z=0;z<takelength;z++)
           {
           	makeString[z]=takechar[z];
		   }
               
           makeString[z]='\0';
           length=takelength;
		   }
          
       }
       
       
       
        void addEnd(myString addend, bool & methodStatus){
           int takelength=length+addend.size();
          
           if(takelength>25){
               methodStatus=false;
               return;
           }
           else
           {
           	methodStatus=true;
           	int x=length,y;
           	 for(  y=0;y<addend.size();y++)
           	 {
           	 	makeString[x]=addend.charAt(y,methodStatus);
           	 	x++;
				}
               
           makeString[x]='\0';
           length=takelength;
           	
		   }

       }
       
       
       
       
       void replWholeString(myString wholestring, bool & methodStatus){
       	  int takelength=wholestring.size();
       	   if(takelength>25)
       	   {
       	   	methodStatus=false;
       	   	return;
       	   	
			  }
       	
       	   else
       	   {
       	   	methodStatus=true;
       	   	
       	   	setString(wholestring.getString(),methodStatus);
			  }
           
       }
       
       
       
       
     
     myString partString(int startPos,int userlength, bool & methodStatus){
     	
     	
     	
     	
     	if(startPos<0 || startPos>length)
     	{
     		methodStatus=false;
     
		 }
     	
     	else
     	{
     		
     		myString partstring;
     		
     		if(userlength>length-startPos)
     		{
     			userlength=length-startPos;
     			
			 }
			 
			 
			 int x=startPos;
			 int y;
     		for( y=0;y<userlength; y++)
     		{
     			partstring.makeString[y]=makeString[x];
     			x++;
			 }
    partstring.makeString[y]='\0';
    length=userlength;
               return partstring;
     		
		 }
     	

          
       }
       
       
       
       
       
     void replPartString(myString partstring,int startPos, bool & methodStatus){
     	
     	
       	  int takelength=partstring.size();
       	   if(takelength>25&&startPos<0 || startPos>takelength-1)
       	   {
       	   	methodStatus=false;
       	   	return;
       	   	
			  }
       	
       	   else
       	   {
       	   	methodStatus=true;
       	   	
       	   	
       	   	
       	   	
       	   	
       	   	myString secpartstring;
       	   	
       	   	int stop=takelength-startPos;
       	   	secpartstring=partstring.partString(startPos,stop ,methodStatus);
       	  
       	   	
       	   
       	   	setString(secpartstring.getString(),methodStatus);
			  }
           
       }
     
     
     
     
       
    
};
