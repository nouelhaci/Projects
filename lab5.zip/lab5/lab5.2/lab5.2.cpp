// Lab 5 project 2
/*
   Noureddine Ouelhaci
   program  to determine when "stack overflow" limit reached.
   October 13,2021
*/



#include <iostream>

using namespace std;

int factorial(int value, bool &methodStatus) {
    if(value < 0) {
        methodStatus = false;
        return -1;
    } 
	else if(value == 0) {
    	methodStatus=true;
        return 1;
    } 
    	//int take=value * factorial(value-1, methodStatus);
        return value * factorial(value-1, methodStatus);
    
}

int main() {
    bool methodStatus = NULL;
    int value=NULL;
    char sentinel='y';
    
    
    
    
    while(sentinel=='y'||sentinel=='Y')
    {
    	cout<<"Please enter an integer whose factorial you'd like to compute:";
    	cin>>value;
    	int output=factorial( value,  methodStatus);
    	
    	if(methodStatus==true)
    	{
    		cout<<"The factorial of  "<<value<<" is "<<output<<endl;
		}
    	else if(methodStatus==false)
    	{
    		cout<<"Please retry with a value greater than 0"<<endl;
		}
    	cout<<"Enter 'y' or 'Y' to continue. all other input quits program";
    	cin>>sentinel;
    	
    	
    	
    	
    	
	}
    
    return 0;
}
