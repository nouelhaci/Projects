// Lab 5 project 1
/*
   Noureddine Ouelhaci
   program  to determine when "stack overflow" limit reached.
   October 13,2021
*/



#include<iostream>
using namespace std;
#define LENGTH  5000 
void arrayInit(int input[],int size);
int recursiveLinearSearch(int array[],int key, int size, int starter, bool & methodStatus);
int main()

{

const int size=LENGTH;


    int thatOneArray[size];


arrayInit( thatOneArray, size);






bool  methodStatus=NULL;
int key=NULL;
int starter=0;
char sentinel='y';

while(sentinel=='y'||sentinel=='Y')
{
	
	while(1)
	{
		cout<<"Enter the value you would like to search for:";
			cin>>key;
			if(key>0&&key<size)
			{
				break;
			}
			else
			{
				
				cout<<"Please enter a value greater than 0 and less than <size>"<<endl;
				
			    
			}
	}
	

	int index=recursiveLinearSearch( thatOneArray, key,  size,  starter+1, methodStatus);
	
	if(methodStatus == true)
	{
		
		cout<<"The value was in position number"<<index+1<<endl;
		cout<<"The function was called "<<index<<" times"<<endl;
	}
	else if(methodStatus ==false)
	{
		
		cout<<"The number does not exist in the array"<<endl;
		cout<<"The function was called "<<index<<" times"<<endl;
	}
	cout<<"Would you like to continue? enter y or Y, all other entries exits program";
	cin>>sentinel;
	
}











return 0;

}
void arrayInit(int input[],int size)
{
	
	for(int x=0;x<size;x++)
	{
		input[x]=x;
		
	}
	
	
	
	
	
}
int recursiveLinearSearch(int array[],int key, int size, int starter, bool & methodStatus){


if(array[starter]==key){

methodStatus = true;

return starter;

}
if(starter>size&&starter!=key){

methodStatus = false;

return 0;
}
else
{
	int returner=recursiveLinearSearch( array, key,  size,  starter+1,   methodStatus);
	return returner;
}




}
