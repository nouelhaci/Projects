import java.io.*;
class Client
{
    private AbstractCamera AbstractCamera;
    private AbstractScreen AbstractScreen;
    private AbstractGPU AbstractGPU;

    public Client(AbstractFactoryWidget factory)
    {
        AbstractScreen = factory.CreateScreen();
        AbstractCamera = factory.CreateCamera();
        AbstractGPU = factory.CreateGPU();
    }
    public void Run()
    {
        AbstractScreen.DisplayName(AbstractScreen);
        AbstractCamera.DisplayName(AbstractCamera);
        AbstractGPU.DisplayName(AbstractGPU);
    }

}









class CameraIphone11 extends AbstractCamera
{

    @Override
    public  void DisplayName(AbstractCamera a)
    {
        System.out.println(" Camera iPhone 11 ");
    }
}


class CameraIphone12 extends AbstractCamera
{
    @Override public  void DisplayName(AbstractCamera a)
    {
        System.out.println(" Camera iPhone 12 " );
    }
}
class CameraIphone13 extends AbstractCamera
{
    @Override public  void DisplayName(AbstractCamera a)
    {
        System.out.println(" Camera iPhone 13 ");
    }
}
class CameraIphone14 extends AbstractCamera
{
    @Override public  void DisplayName(AbstractCamera a)
    {
        System.out.println(" Camera iPhone 14 ");
    }
}












class ScreenIphone11 extends AbstractScreen
{
    @Override public  void DisplayName(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 11 " );
    }
}
class ScreenIphone12 extends AbstractScreen
{

    @Override public  void DisplayName(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 12 " );
    }
}
class ScreenIphone13 extends AbstractScreen
{

    @Override public  void DisplayName(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 13 " );
    }
}
class ScreenIphone14 extends AbstractScreen
{

    @Override public  void DisplayName(AbstractScreen a)
    {
        System.out.println(" Screen iPhone 14 " );
    }
}







class GPUIphone11 extends AbstractGPU
{
    @Override public  void DisplayName(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 11 " );
    }
}
class GPUIphone12 extends AbstractGPU
{

    @Override public  void DisplayName(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 12 " );
    }
}
class GPUIphone13 extends AbstractGPU
{

    @Override public  void DisplayName(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 13 " );
    }
}
class GPUIphone14 extends AbstractGPU
{

    @Override public  void DisplayName(AbstractGPU a)
    {
        System.out.println(" GPU iPhone 14 " );
    }
}


















abstract class AbstractCamera
{
    public abstract void DisplayName(AbstractCamera a);
}

abstract class AbstractScreen
{
    public abstract void DisplayName(AbstractScreen a);
}

abstract class AbstractGPU
{
    public abstract void DisplayName(AbstractGPU a);
}

abstract class AbstractFactoryWidget
{

    private boolean Iphonevalidation=false;
    public boolean check(int number) {
        if(number==1)
        {
            SingleIphone11 Iph11 = SingleIphone11.getIphone11();
            if (Iph11 != null)
            {
                Iphonevalidation=true;

            }
            if (Iph11 == null)
            {
                Iphonevalidation=false;

            }
        }
        if(number==2)
        {
            SingleIphone12 Iph12 = SingleIphone12.getIphone12();
            if (Iph12 != null)
            {
                Iphonevalidation=true;

            }
            if (Iph12 == null)
            {
                Iphonevalidation=false;

            }
        }
        if(number==3)
        {
            SingleIphone13 Iph13 = SingleIphone13.getIphone13();
            if (Iph13 != null)
            {
                Iphonevalidation=true;

            }
            if (Iph13 == null)
            {
                Iphonevalidation=false;

            }
        }
        if(number==4)
        {
            SingleIphone14 Iph14 = SingleIphone14.getIphone14();
            if (Iph14 != null)
            {
                Iphonevalidation=true;

            }
            if (Iph14 == null)
            {
                Iphonevalidation=false;

            }
        }
        return Iphonevalidation;
    }


    public abstract AbstractCamera
    CreateCamera();
    public abstract AbstractScreen
    CreateScreen();
    public abstract AbstractGPU
    CreateGPU();
}










class ConcreteIphone11 extends AbstractFactoryWidget {


    @Override public  AbstractCamera CreateCamera() {
        return new CameraIphone11();
    }
    @Override public  AbstractScreen CreateScreen() {
        return new ScreenIphone11();
    }
    @Override public  AbstractGPU CreateGPU() {
        return new GPUIphone11();
    }
}
class ConcreteIphone12 extends AbstractFactoryWidget {

    @Override public  AbstractCamera CreateCamera() {
        return new CameraIphone12();
    }
    @Override public  AbstractScreen CreateScreen() {
        return new ScreenIphone12();
    }
    @Override public  AbstractGPU CreateGPU() {
        return new GPUIphone12();
    }
}

class ConcreteIphone13 extends AbstractFactoryWidget {
    @Override public  AbstractCamera CreateCamera() {
        return new CameraIphone13();
    }
    @Override public  AbstractScreen CreateScreen() {
        return new ScreenIphone13();
    }
    @Override public  AbstractGPU CreateGPU() {
        return new GPUIphone13();
    }
}
class ConcreteIphone14 extends AbstractFactoryWidget {
    @Override public  AbstractCamera CreateCamera() {
        return new CameraIphone14();
    }
    @Override public  AbstractScreen CreateScreen() {
        return new ScreenIphone14();
    }
    @Override public  AbstractGPU CreateGPU() {
        return new GPUIphone14();
    }
}



class SingleIphone11 {
    private static boolean instance_flag= false;
    private static int x= 0;
    private SingleIphone11()  {
    }
    public static SingleIphone11 getIphone11() {
        x++;
        if (! instance_flag) {
            if(x==2)
            {
                instance_flag = true;
            }

            return new SingleIphone11();
        }
        else
            return null;
    }
}

class SingleIphone12 {
    private static boolean instance_flag= false;
    private static int x= 0;
    private SingleIphone12()  {
    }
    public static SingleIphone12 getIphone12() {
        x++;
        if (! instance_flag) {
            if(x==2)
            {
                instance_flag = true;
            }

            return new SingleIphone12();
        }
        else
            return null;
    }
}

class SingleIphone13 {
    private static boolean instance_flag= false;
    private static int x= 0;
    private SingleIphone13()  {
    }
    public static SingleIphone13 getIphone13() {
        x++;
        if (! instance_flag) {
            if(x==2)
            {
                instance_flag = true;
            }

            return new SingleIphone13();
        }
        else
            return null;
    }
}



class SingleIphone14 {
    private static boolean instance_flag= false;
    private static int x= 0;
    private SingleIphone14()  {
    }
    public static SingleIphone14 getIphone14() {
        x++;
        if (! instance_flag) {
            if(x==2)
            {
                instance_flag = true;
            }

            return new SingleIphone14();
        }
        else
            return null;
    }
}

public class Main {
    public static void main(String[] args) throws Exception {

        AbstractFactoryWidget FactoryIphone11 = new ConcreteIphone11();
        Client c1 = new Client(FactoryIphone11);
        AbstractFactoryWidget FactoryIphone12 = new ConcreteIphone12();
        Client c2 = new Client(FactoryIphone12);
        AbstractFactoryWidget FactoryIphone13 = new ConcreteIphone13();
        Client c3 = new Client(FactoryIphone13);
        AbstractFactoryWidget FactoryIphone14 = new ConcreteIphone14();
        Client c4 = new Client(FactoryIphone14);
        File file = new File("C:\\Users\\13139\\Desktop\\project1\\Project1code\\src\\file.txt");
        BufferedReader br = new BufferedReader(new FileReader(file));
        String st;
        while ((st = br.readLine()) != null){
           if(st.equals("iPhone 11"))
            {

                if(FactoryIphone11.check(1))
                {
                    System.out.println(st+":");
                    c1.Run();
                }
                else
                    System.out.println("Can\'t get Third iPhone 11");
            }

            if(st.equals("iPhone 12"))
            {
                if(FactoryIphone12.check(2))
                {
                    System.out.println(st+":");
                    c2.Run();
                }
                else
                    System.out.println("Can\'t get Third iPhone 12");
            }
           if(st.equals("iPhone 13"))
            {
                if(FactoryIphone13.check(3))
                {
                    System.out.println(st+":");
                    c3.Run();
                }
                else
                    System.out.println("Can\'t get Third iPhone 13");
            }

            if(st.equals("iPhone 14"))
            {
                if(FactoryIphone14.check(4))
                {
                    System.out.println(st+":");
                    c4.Run();
                }
                else
                    System.out.println("Can\'t get Third iPhone 14");
            }
        }









    }
}